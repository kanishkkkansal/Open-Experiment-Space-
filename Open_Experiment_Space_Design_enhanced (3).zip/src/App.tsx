import { useState } from "react";
import Workspace from "./Workspace";

type Screen = "landing" | "modules" | "workspace";

// ─── Shared UI ────────────────────────────────────────────────────────────────

function Logo({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const sz = size === "sm" ? "w-7 h-7" : size === "lg" ? "w-10 h-10" : "w-8 h-8";
  const txt = size === "sm" ? "text-base" : size === "lg" ? "text-2xl" : "text-lg";
  return (
    <div className="flex items-center gap-2.5">
      <div className={`${sz} rounded-xl bg-[var(--chem)] flex items-center justify-center flex-shrink-0`}>
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
          <path d="M9 3h6v6l3 10H6L9 9V3zm-1-1a1 1 0 000 2h1v6.17L6.1 20.4A1 1 0 007 22h10a1 1 0 00.9-1.6L15 10.17V4h1a1 1 0 000-2H8z" />
        </svg>
      </div>
      <div>
        <div className={`${txt} font-semibold text-[var(--text)] leading-none`}>Open Experiment</div>
        <div className="text-[10px] font-medium text-[var(--chem)] tracking-widest uppercase leading-none mt-0.5">Space</div>
      </div>
    </div>
  );
}

function Btn({
  children, onClick, variant = "primary", size = "md", className = ""
}: {
  children: React.ReactNode; onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "outline";
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const base = "inline-flex items-center gap-2 font-medium rounded-xl transition-all duration-150 cursor-pointer";
  const sizes = { sm: "px-3 py-1.5 text-sm", md: "px-5 py-2.5 text-sm", lg: "px-7 py-3.5 text-base" };
  const variants = {
    primary: "bg-[var(--chem)] text-white hover:bg-[var(--chem-hover)] shadow-sm",
    secondary: "bg-[var(--chem-muted)] text-[var(--chem)] hover:bg-[var(--chem-light)]",
    ghost: "text-[var(--muted)] hover:text-[var(--text)] hover:bg-slate-100",
    outline: "border border-[var(--border)] text-[var(--text)] hover:border-slate-300 hover:bg-slate-50",
  };
  return (
    <button onClick={onClick} className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}>
      {children}
    </button>
  );
}

// ─── Top Nav ──────────────────────────────────────────────────────────────────

function TopNav({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-14 bg-white/90 backdrop-blur border-b border-[var(--border)] flex items-center px-6 gap-6">
      <button onClick={() => onNavigate("landing")} className="cursor-pointer">
        <Logo size="sm" />
      </button>
      <nav className="flex items-center gap-1 ml-4">
        <button onClick={() => onNavigate("landing")} className="text-sm text-[var(--muted)] hover:text-[var(--text)] px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors">Home</button>
        <button onClick={() => onNavigate("modules")} className="text-sm text-[var(--muted)] hover:text-[var(--text)] px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors">Lab Modules</button>
      </nav>
      <div className="ml-auto flex items-center gap-3">
        <Btn variant="outline" size="sm">Sign in</Btn>
        <Btn size="sm" onClick={() => onNavigate("modules")}>Start experimenting</Btn>
      </div>
    </header>
  );
}

// ─── Landing Screen ───────────────────────────────────────────────────────────

function Landing({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full bg-[var(--bg)]">
      <TopNav onNavigate={onNavigate} />

      {/* Hero */}
      <section className="pt-28 pb-20 px-6 max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="inline-flex items-center gap-2 bg-[var(--chem-muted)] text-[var(--chem)] text-xs font-semibold px-3 py-1.5 rounded-full mb-6 tracking-wide uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--chem)] live-dot" />
            Open-source · Free for all schools
          </div>
          <h1 className="text-4xl lg:text-5xl font-bold text-[var(--text)] leading-[1.15] mb-5">
            The virtual science lab<br />
            <span className="text-[var(--chem)]">India's schools deserve.</span>
          </h1>
          <p className="text-lg text-[var(--muted)] leading-relaxed mb-8 max-w-lg">
            A free, open-ended virtual chemistry lab designed for government and under-resourced schools — no equipment, no cost, no compromise on quality education.
          </p>
          <div className="flex flex-wrap gap-3">
            <Btn size="lg" onClick={() => onNavigate("modules")}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Start your first experiment
            </Btn>
            <Btn variant="outline" size="lg">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Learn more
            </Btn>
          </div>
          <p className="text-xs text-[var(--muted)] mt-5">Works in any modern browser · No installation · No account required</p>
        </div>

        {/* Hero visual */}
        <div className="relative">
          <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-emerald-900/10 border border-[var(--border)]">
            <img
              src="https://images.unsplash.com/photo-1694230155228-cdde50083573?w=720&h=480&fit=crop&auto=format"
              alt="Colorful chemistry lab test tubes"
              className="w-full h-72 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4 right-4">
              <div className="bg-white/95 backdrop-blur rounded-xl p-3 shadow-lg flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[var(--chem-muted)] flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-[var(--chem)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                </div>
                <div>
                  <div className="text-xs font-semibold text-[var(--text)]">AI Lab Assistant says:</div>
                  <div className="text-xs text-[var(--muted)] mt-0.5">"pH is now 7.02 — you've reached the equivalence point!"</div>
                </div>
              </div>
            </div>
          </div>
          {/* floating stat badges */}
          <div className="absolute -top-3 -right-3 bg-white rounded-xl px-3 py-2 shadow-lg border border-[var(--border)]">
            <div className="text-xs text-[var(--muted)]">Live pH reading</div>
            <div className="text-xl font-bold text-[var(--chem)] font-mono">7.02</div>
          </div>
          <div className="absolute -bottom-3 -left-3 bg-white rounded-xl px-3 py-2 shadow-lg border border-[var(--border)]">
            <div className="text-xs text-[var(--muted)]">Endpoint reached</div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="w-3 h-3 rounded-full bg-pink-400 inline-block" />
              <span className="text-sm font-semibold text-[var(--text)]">Pink · Phenolphthalein</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3-step visual */}
      <section className="py-16 px-6 bg-white border-y border-[var(--border)]">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-center text-[var(--text)] mb-2">How it works</h2>
          <p className="text-[var(--muted)] text-center mb-10">Three steps from curiosity to understanding</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
            {[
              { n: "01", title: "Select", desc: "Choose chemicals and apparatus from the sidebar. Drag them onto your virtual lab bench.", icon: "M4 6h16M4 10h16M4 14h16M4 18h16" },
              { n: "02", title: "Combine", desc: "Mix chemicals, heat solutions, run titrations. The simulation responds in real time.", icon: "M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" },
              { n: "03", title: "Learn", desc: "Your AI Lab Assistant explains every reaction. Ask what-if questions and explore freely.", icon: "M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" },
            ].map((step, i) => (
              <div key={step.n} className="relative">
                {i < 2 && <div className="hidden md:block absolute top-8 left-[calc(100%+1px)] w-full h-px bg-[var(--border)] z-0" />}
                <div className="relative z-10 bg-[var(--bg)] border border-[var(--border)] rounded-2xl p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-[var(--chem-muted)] flex items-center justify-center flex-shrink-0">
                      <svg className="w-5 h-5 text-[var(--chem)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d={step.icon} />
                      </svg>
                    </div>
                    <div>
                      <div className="text-xs font-mono text-[var(--muted)] mb-1">{step.n}</div>
                      <div className="text-lg font-semibold text-[var(--text)] mb-2">{step.title}</div>
                      <div className="text-sm text-[var(--muted)] leading-relaxed">{step.desc}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why we built this */}
      <section className="py-16 px-6 max-w-5xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-xs font-semibold text-[var(--chem)] uppercase tracking-widest mb-3">Why we built this</div>
            <h2 className="text-3xl font-bold text-[var(--text)] mb-5">Most Indian school students never touch a real lab.</h2>
            <p className="text-[var(--muted)] leading-relaxed mb-6">
              Over 40% of government secondary schools lack a functioning science lab. Students read about titrations and electrolysis without ever performing them — and that gap shows up in board exam scores and in lifelong scientific curiosity.
            </p>
            <p className="text-[var(--muted)] leading-relaxed mb-8">
              Open Experiment Space is our answer: a fully simulated, open-ended virtual lab that runs on any browser, even on a shared desktop from 2015. No equipment budgets, no chemicals to store, no safety waivers. Just experiments.
            </p>
            <Btn onClick={() => onNavigate("modules")}>Open the lab →</Btn>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { stat: "40%+", label: "govt. schools without a working science lab", color: "text-rose-500" },
              { stat: "28M", label: "secondary students who never run a chemistry experiment", color: "text-amber-500" },
              { stat: "0₹", label: "cost to use Open Experiment Space — forever free", color: "text-[var(--chem)]" },
              { stat: "Any", label: "device — works on a 2015 shared school computer", color: "text-[var(--phys)]" },
            ].map((s) => (
              <div key={s.stat} className="bg-white border border-[var(--border)] rounded-2xl p-5">
                <div className={`text-3xl font-bold ${s.color} mb-1`}>{s.stat}</div>
                <div className="text-xs text-[var(--muted)] leading-snug">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Roadmap */}
      <section className="py-16 px-6 bg-white border-t border-[var(--border)]">
        <div className="max-w-5xl mx-auto">
          <div className="text-xs font-semibold text-[var(--muted)] uppercase tracking-widest mb-2 text-center">Roadmap</div>
          <h2 className="text-2xl font-bold text-center text-[var(--text)] mb-10">Science, all of it.</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { sub: "Chemistry", status: "available", icon: "⚗️", color: "var(--chem)", light: "var(--chem-muted)" },
              { sub: "Physics", status: "coming soon", icon: "⚡", color: "var(--phys)", light: "var(--phys-light)" },
              { sub: "Electronics", status: "planned", icon: "🔌", color: "#F97316", light: "#FFF7ED" },
              { sub: "Biology", status: "planned", icon: "🧬", color: "#0284C7", light: "#E0F2FE" },
            ].map((m) => (
              <div
                key={m.sub}
                className="border border-[var(--border)] rounded-2xl p-5 text-center hover:shadow-md transition-shadow cursor-default"
                style={{ background: m.status === "available" ? m.light : "white" }}
              >
                <div className="text-3xl mb-3">{m.icon}</div>
                <div className="font-semibold text-[var(--text)] text-sm mb-1">{m.sub}</div>
                <div
                  className="text-xs px-2 py-0.5 rounded-full inline-block font-medium"
                  style={{
                    color: m.status === "available" ? m.color : "var(--muted)",
                    background: m.status === "available" ? m.light : "#F1F5F9",
                  }}
                >
                  {m.status === "available" ? "Available now" : m.status === "coming soon" ? "Coming soon" : "Planned"}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-[var(--border)] text-center">
        <Logo size="sm" />
        <p className="text-xs text-[var(--muted)] mt-3">Open-source · Free for students and teachers · Built for India</p>
      </footer>
    </div>
  );
}

// ─── Modules Screen ───────────────────────────────────────────────────────────

function Modules({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full bg-[var(--bg)]">
      <TopNav onNavigate={onNavigate} />
      <div className="pt-28 pb-16 px-6 max-w-4xl mx-auto">
        <div className="mb-10">
          <div className="text-xs font-semibold text-[var(--chem)] uppercase tracking-widest mb-2">Lab Modules</div>
          <h1 className="text-3xl font-bold text-[var(--text)] mb-2">Choose your subject</h1>
          <p className="text-[var(--muted)]">Select a module to begin experimenting</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Chemistry — available */}
          <div
            className="bg-white border-2 border-[var(--chem)] rounded-2xl p-7 cursor-pointer hover:shadow-lg hover:shadow-emerald-900/8 transition-all group"
            onClick={() => onNavigate("workspace")}
          >
            <div className="flex items-start justify-between mb-6">
              <div className="w-14 h-14 rounded-2xl bg-[var(--chem-muted)] flex items-center justify-center">
                <svg viewBox="0 0 40 40" className="w-7 h-7" fill="none">
                  <path d="M15 6h10v10l8 18H7L15 16V6z" stroke="#059669" strokeWidth="2.5" strokeLinejoin="round" />
                  <path d="M10 28h20" stroke="#059669" strokeWidth="2" />
                  <circle cx="16" cy="32" r="2" fill="#059669" opacity=".5" />
                  <circle cx="22" cy="30" r="1.5" fill="#059669" opacity=".3" />
                </svg>
              </div>
              <span className="text-xs font-semibold text-[var(--chem)] bg-[var(--chem-muted)] px-3 py-1 rounded-full">Available now</span>
            </div>
            <h2 className="text-xl font-bold text-[var(--text)] mb-2">Chemistry Lab</h2>
            <p className="text-sm text-[var(--muted)] mb-6 leading-relaxed">Perform titrations, test pH, run electrolysis, grow crystals — with an AI assistant that explains every reaction.</p>
            <div className="flex flex-wrap gap-2 mb-6">
              {["Acid-Base Titration", "Electrolysis", "Crystal Growth", "pH Testing"].map(t => (
                <span key={t} className="text-xs bg-[var(--chem-muted)] text-[var(--chem)] px-2.5 py-1 rounded-lg">{t}</span>
              ))}
            </div>
            <Btn className="w-full justify-center">Open Chemistry Lab →</Btn>
          </div>

          {/* Physics — coming soon */}
          <div className="bg-white border border-[var(--border)] rounded-2xl p-7 opacity-80">
            <div className="flex items-start justify-between mb-6">
              <div className="w-14 h-14 rounded-2xl bg-[var(--phys-light)] flex items-center justify-center">
                <svg viewBox="0 0 40 40" className="w-7 h-7" fill="none">
                  <circle cx="20" cy="20" r="12" stroke="#7C3AED" strokeWidth="2.5" />
                  <ellipse cx="20" cy="20" rx="12" ry="5" stroke="#7C3AED" strokeWidth="2" />
                  <line x1="20" y1="8" x2="20" y2="32" stroke="#7C3AED" strokeWidth="2" />
                  <circle cx="20" cy="20" r="2.5" fill="#7C3AED" />
                </svg>
              </div>
              <span className="text-xs font-semibold text-[var(--phys)] bg-[var(--phys-light)] px-3 py-1 rounded-full">Coming soon</span>
            </div>
            <h2 className="text-xl font-bold text-[var(--text)] mb-2">Physics Lab</h2>
            <p className="text-sm text-[var(--muted)] mb-6 leading-relaxed">Explore optics, mechanics, and electricity with interactive simulations and real-time measurements.</p>
            <div className="flex flex-wrap gap-2 mb-6">
              {["Optics", "Circuits", "Mechanics", "Waves"].map(t => (
                <span key={t} className="text-xs bg-[var(--phys-light)] text-[var(--phys)] px-2.5 py-1 rounded-lg">{t}</span>
              ))}
            </div>
            <Btn variant="outline" className="w-full justify-center cursor-not-allowed opacity-60">Notify me when ready</Btn>
          </div>

          {/* Electronics */}
          <div className="bg-white border border-[var(--border)] rounded-2xl p-6 opacity-70">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-orange-50 flex items-center justify-center">
                <svg viewBox="0 0 40 40" className="w-6 h-6" fill="none">
                  <rect x="8" y="14" width="24" height="12" rx="2" stroke="#F97316" strokeWidth="2.5" />
                  <line x1="14" y1="14" x2="14" y2="10" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                  <line x1="20" y1="14" x2="20" y2="10" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                  <line x1="26" y1="14" x2="26" y2="10" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                  <line x1="14" y1="30" x2="14" y2="26" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                  <line x1="26" y1="30" x2="26" y2="26" stroke="#F97316" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <span className="text-xs font-semibold text-orange-500 bg-orange-50 px-3 py-1 rounded-full">Planned</span>
            </div>
            <h2 className="text-lg font-bold text-[var(--text)] mb-1">Digital Electronics</h2>
            <p className="text-xs text-[var(--muted)]">Logic gates, circuit simulation, and digital systems.</p>
          </div>

          {/* Biology */}
          <div className="bg-white border border-[var(--border)] rounded-2xl p-6 opacity-70">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-sky-50 flex items-center justify-center">
                <svg viewBox="0 0 40 40" className="w-6 h-6" fill="none">
                  <path d="M20 8C14 8 10 14 12 22c2 8 10 10 12 10 2 0 10-2 12-10 2-8-2-14-8-14" stroke="#0284C7" strokeWidth="2.5" strokeLinecap="round" />
                  <path d="M20 14v12M14 20h12" stroke="#0284C7" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <span className="text-xs font-semibold text-sky-500 bg-sky-50 px-3 py-1 rounded-full">Planned</span>
            </div>
            <h2 className="text-lg font-bold text-[var(--text)] mb-1">Biology Lab</h2>
            <p className="text-xs text-[var(--muted)]">Cell biology, microscopy, and genetics simulations.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── App Root ─────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("landing");
  const navigate = (s: Screen) => setScreen(s);

  if (screen === "workspace") return <Workspace onBack={() => navigate("modules")} />;
  if (screen === "modules") return <Modules onNavigate={navigate} />;
  return <Landing onNavigate={navigate} />;
}
