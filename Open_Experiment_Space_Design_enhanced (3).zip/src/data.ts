export interface LabItem {
  id: string;
  name: string;
  formula?: string;
  abbrev: string;       // short label shown in the sidebar icon
  category: "apparatus" | "chemical";
  subcategory: string;
  iconColor: string;
  bgColor: string;
  liquidColor?: string; // solution colour for simulation
}

export interface ItemGroup {
  id: string;
  label: string;
  items: LabItem[];
}

// ─── Apparatus ────────────────────────────────────────────────────────────────

const AP = (id: string, name: string, abbrev: string, sub: string): LabItem => ({
  id, name, abbrev, category: "apparatus", subcategory: sub,
  iconColor: "#475569", bgColor: "#F1F5F9",
});

export const APPARATUS_GROUPS: ItemGroup[] = [
  {
    id: "glassware", label: "Glassware",
    items: [
      AP("burette", "Burette", "Brt", "glassware"),
      AP("conical", "Conical Flask", "250ml", "glassware"),
      AP("beaker", "Beaker", "Bkr", "glassware"),
      AP("pipette", "Pipette", "Pip", "glassware"),
      AP("volumetric", "Volumetric Flask", "Volm", "glassware"),
      AP("cylinder", "Measuring Cylinder", "Cyl", "glassware"),
      AP("test_tube", "Test Tube", "TT", "glassware"),
      AP("boiling_tube", "Boiling Tube", "BoilT", "glassware"),
      AP("watch_glass", "Watch Glass", "W.Gl", "glassware"),
      AP("round_flask", "Round-Bottom Flask", "RBF", "glassware"),
      AP("funnel", "Funnel", "Fnl", "glassware"),
    ],
  },
  {
    id: "stands", label: "Stands & Holders",
    items: [
      AP("retort_stand", "Retort Stand", "Stnd", "stands"),
      AP("test_tube_stand", "Test Tube Stand", "TTStnd", "stands"),
      AP("test_tube_holder", "Test Tube Holder", "TTHld", "stands"),
      AP("tripod_stand", "Tripod Stand", "Trpd", "stands"),
      AP("wire_gauze", "Wire Gauze", "W.Gz", "stands"),
      AP("clay_triangle", "Clay Triangle", "ClTri", "stands"),
    ],
  },
  {
    id: "small", label: "Small & Consumables",
    items: [
      AP("dropper", "Dropper", "Drp", "small"),
      AP("glass_rod", "Glass Rod", "G.Rod", "small"),
      AP("spatula", "Spatula", "Spat", "small"),
      AP("wash_bottle", "Wash Bottle", "W.Bot", "small"),
      AP("pipette_bulb", "Pipette Bulb", "Bulb", "small"),
      AP("delivery_tube", "Delivery Tube", "D.Tube", "small"),
      AP("china_dish", "China Dish", "C.Dish", "small"),
      AP("white_tile", "White Tile", "Tile", "small"),
      AP("nichrome_wire", "Nichrome Wire", "NiWire", "small"),
    ],
  },
  {
    id: "test_strips", label: "Test Strips & Papers",
    items: [
      AP("filter_paper", "Filter Paper", "Filtr", "test_strips"),
      AP("litmus_red", "Litmus Paper (Red)", "LitR", "test_strips"),
      AP("litmus_blue", "Litmus Paper (Blue)", "LitB", "test_strips"),
      AP("lead_acetate_paper", "Lead Acetate Paper", "PbAc.", "test_strips"),
      AP("turmeric_paper", "Turmeric Paper", "Turm.", "test_strips"),
    ],
  },
  {
    id: "heating", label: "Heating",
    items: [
      AP("bunsen", "Bunsen Burner", "Bunsen", "heating"),
      AP("spirit_lamp", "Spirit Lamp", "Spirit", "heating"),
      AP("water_bath", "Water Bath", "W.Bath", "heating"),
    ],
  },
];

// ─── Chemicals ────────────────────────────────────────────────────────────────

type ChemArgs = [string, string, string, string, string, string, (string | undefined)?];
const CH = (id: string, name: string, formula: string, abbrev: string, sub: string, ic: string, bg: string, liq?: string): LabItem => ({
  id, name, formula, abbrev, category: "chemical", subcategory: sub,
  iconColor: ic, bgColor: bg, liquidColor: liq,
});

export const CHEMICAL_GROUPS: ItemGroup[] = [
  {
    id: "acids", label: "Acids",
    items: [
      CH("hcl_dil", "HCl (dilute)", "HCl", "HCl(d)", "acids", "#B91C1C", "#FEE2E2", "rgba(254,249,195,0.3)"),
      CH("hcl_conc", "HCl (conc.)", "HCl", "HCl(c)", "acids", "#991B1B", "#FEE2E2", "rgba(254,249,195,0.4)"),
      CH("h2so4_dil", "H₂SO₄ (dilute)", "H₂SO₄", "H₂SO₄(d)", "acids", "#B91C1C", "#FEE2E2", "rgba(254,249,195,0.2)"),
      CH("h2so4_conc", "H₂SO₄ (conc.)", "H₂SO₄", "H₂SO₄(c)", "acids", "#991B1B", "#FEE2E2", "rgba(254,249,195,0.4)"),
      CH("hno3_dil", "HNO₃ (dilute)", "HNO₃", "HNO₃(d)", "acids", "#B91C1C", "#FEE2E2", "rgba(254,249,195,0.2)"),
      CH("hno3_conc", "HNO₃ (conc.)", "HNO₃", "HNO₃(c)", "acids", "#991B1B", "#FEE2E2", "rgba(255,237,213,0.5)"),
    ],
  },
  {
    id: "bases", label: "Bases",
    items: [
      CH("naoh", "NaOH", "NaOH", "NaOH", "bases", "#1D4ED8", "#DBEAFE", "rgba(219,234,254,0.3)"),
      CH("koh", "KOH", "KOH", "KOH", "bases", "#1D4ED8", "#DBEAFE", "rgba(219,234,254,0.3)"),
      CH("nh4oh", "NH₄OH", "NH₄OH", "NH₄OH", "bases", "#1E40AF", "#EFF6FF", "rgba(239,246,255,0.4)"),
      CH("lime_water", "Lime Water", "Ca(OH)₂", "Ca(OH)₂", "bases", "#1D4ED8", "#DBEAFE", "rgba(241,245,249,0.3)"),
      CH("caoh2", "Ca(OH)₂ (solid)", "Ca(OH)₂", "Ca(OH)₂", "bases", "#1E40AF", "#DBEAFE", undefined),
    ],
  },
  {
    id: "standards", label: "Titration Standards",
    items: [
      CH("na2co3", "Na₂CO₃", "Na₂CO₃", "Na₂CO₃", "standards", "#047857", "#D1FAE5", "rgba(209,250,229,0.4)"),
      CH("oxalic_acid", "Oxalic Acid", "(COOH)₂", "Oxalic", "standards", "#7C3AED", "#EDE9FE", "rgba(237,233,254,0.3)"),
      CH("mohrs_salt", "Mohr's Salt", "FeSO₄·(NH₄)₂SO₄", "Mohr's", "standards", "#6D28D9", "#EDE9FE", "#A7F3D0"),
      CH("kmno4", "KMnO₄", "KMnO₄", "KMnO₄", "standards", "#6B21A8", "#F3E8FF", "#7B2D8B"),
      CH("na2c2o4", "Sodium Oxalate", "Na₂C₂O₄", "Na₂C₂O₄", "standards", "#5B21B6", "#EDE9FE", "rgba(237,233,254,0.3)"),
    ],
  },
  {
    id: "indicators", label: "Indicators",
    items: [
      CH("phenol", "Phenolphthalein", "—", "Phenol.", "indicators", "#DB2777", "#FCE7F3", "rgba(255,255,255,0.05)"),
      CH("methyl_orange", "Methyl Orange", "—", "M.Org.", "indicators", "#D97706", "#FEF3C7", "#FDE68A"),
      CH("litmus_soln", "Litmus Solution", "—", "Litmus", "indicators", "#7C3AED", "#EDE9FE", "#C4B5FD"),
      CH("starch_soln", "Starch Solution", "—", "Starch", "indicators", "#475569", "#F1F5F9", "rgba(241,245,249,0.5)"),
    ],
  },
  {
    id: "cation_salts", label: "Cation Salts",
    items: [
      CH("cuso4", "CuSO₄", "CuSO₄", "CuSO₄", "cation_salts", "#1D4ED8", "#DBEAFE", "#93C5FD"),
      CH("pb_no3", "Pb(NO₃)₂", "Pb(NO₃)₂", "Pb(NO₃)₂", "cation_salts", "#475569", "#F1F5F9", "rgba(241,245,249,0.3)"),
      CH("fecl3", "FeCl₃", "FeCl₃", "FeCl₃", "cation_salts", "#B45309", "#FEF3C7", "#FCD34D"),
      CH("alum", "Alum", "AlK(SO₄)₂", "Alum", "cation_salts", "#475569", "#F8FAFC", "rgba(241,245,249,0.2)"),
      CH("znso4", "ZnSO₄", "ZnSO₄", "ZnSO₄", "cation_salts", "#374151", "#F9FAFB", "rgba(249,250,251,0.4)"),
      CH("mnso4", "MnSO₄", "MnSO₄", "MnSO₄", "cation_salts", "#9D174D", "#FCE7F3", "#FCA5A5"),
      CH("co_no3", "Co(NO₃)₂", "Co(NO₃)₂", "Co(NO₃)₂", "cation_salts", "#DB2777", "#FCE7F3", "#F9A8D4"),
      CH("niso4", "NiSO₄", "NiSO₄", "NiSO₄", "cation_salts", "#15803D", "#DCFCE7", "#86EFAC"),
      CH("cacl2", "CaCl₂", "CaCl₂", "CaCl₂", "cation_salts", "#475569", "#F8FAFC", "rgba(241,245,249,0.2)"),
      CH("bacl2", "BaCl₂", "BaCl₂", "BaCl₂", "cation_salts", "#374151", "#F9FAFB", "rgba(249,250,251,0.2)"),
      CH("srcl2", "SrCl₂", "SrCl₂", "SrCl₂", "cation_salts", "#374151", "#F9FAFB", "rgba(249,250,251,0.2)"),
      CH("mgso4", "MgSO₄", "MgSO₄", "MgSO₄", "cation_salts", "#374151", "#F8FAFC", "rgba(241,245,249,0.2)"),
      CH("nh4cl", "NH₄Cl", "NH₄Cl", "NH₄Cl", "cation_salts", "#475569", "#F1F5F9", "rgba(241,245,249,0.2)"),
    ],
  },
  {
    id: "anion_salts", label: "Anion Salts",
    items: [
      CH("nacl", "NaCl", "NaCl", "NaCl", "anion_salts", "#0D9488", "#CCFBF1", "rgba(204,251,241,0.3)"),
      CH("na2so3", "Na₂SO₃", "Na₂SO₃", "Na₂SO₃", "anion_salts", "#0F766E", "#CCFBF1", "rgba(204,251,241,0.2)"),
      CH("na2s", "Na₂S / (NH₄)₂S", "Na₂S", "Na₂S", "anion_salts", "#92400E", "#FEF3C7", "#FDE68A"),
      CH("nano2", "NaNO₂", "NaNO₂", "NaNO₂", "anion_salts", "#0D9488", "#CCFBF1", "rgba(204,251,241,0.2)"),
      CH("ki", "KI", "KI", "KI", "anion_salts", "#0F766E", "#CCFBF1", "rgba(204,251,241,0.2)"),
      CH("na3po4", "Na₃PO₄", "Na₃PO₄", "Na₃PO₄", "anion_salts", "#0D9488", "#CCFBF1", "rgba(204,251,241,0.2)"),
      CH("ch3coona", "CH₃COONa", "CH₃COONa", "Acetate", "anion_salts", "#0F766E", "#CCFBF1", "rgba(204,251,241,0.2)"),
      CH("kno3", "KNO₃", "KNO₃", "KNO₃", "anion_salts", "#0D9488", "#CCFBF1", "rgba(204,251,241,0.2)"),
    ],
  },
  {
    id: "reagents", label: "Group / Test Reagents",
    items: [
      CH("water", "Distilled Water", "H₂O", "H₂O", "reagents", "#0284C7", "#E0F2FE", "#BFDBFE"),
      CH("agno3", "AgNO₃", "AgNO₃", "AgNO₃", "reagents", "#D97706", "#FEF3C7", "rgba(254,243,199,0.3)"),
      CH("pb_acetate", "Lead Acetate", "Pb(CH₃COO)₂", "PbAcO", "reagents", "#374151", "#F9FAFB", "rgba(249,250,251,0.3)"),
      CH("k4fecn6", "K₄[Fe(CN)₆]", "K₄[Fe(CN)₆]", "K₄[Fe]", "reagents", "#D97706", "#FEF3C7", "#FDE68A"),
      CH("k2cr2o7", "K₂Cr₂O₇", "K₂Cr₂O₇", "K₂Cr₂O₇", "reagents", "#B45309", "#FEF3C7", "#FDBA74"),
      CH("nh4_2co3", "(NH₄)₂CO₃", "(NH₄)₂CO₃", "(NH₄)₂CO₃", "reagents", "#1E40AF", "#DBEAFE", "rgba(219,234,254,0.2)"),
      CH("nesslers", "Nessler's Reagent", "—", "Nessler", "reagents", "#92400E", "#FEF3C7", "#FDE68A"),
      CH("feso4_mohrs", "FeSO₄·(NH₄)₂SO₄", "FeSO₄·(NH₄)₂SO₄", "FeSO₄·(NH₄)₂", "reagents", "#065F46", "#D1FAE5", "#A7F3D0"),
    ],
  },
];

// ─── Flat lookups ─────────────────────────────────────────────────────────────

export const ALL_APPARATUS: LabItem[] = APPARATUS_GROUPS.flatMap(g => g.items);
export const ALL_CHEMICALS: LabItem[] = CHEMICAL_GROUPS.flatMap(g => g.items);
export const ALL_ITEMS: LabItem[] = [...ALL_APPARATUS, ...ALL_CHEMICALS];

export function getItem(id: string): LabItem | undefined {
  return ALL_ITEMS.find(i => i.id === id);
}

// ─── Chemistry simulation ─────────────────────────────────────────────────────

export interface ContentItem {
  chemId: string;
  amountMl: number;
  phase: "solid" | "liquid";
}

// Combine two contents lists, summing amounts for anything that's the same
// chemical + phase already present, instead of piling up a new line per drop.
export function mergeContents(existing: ContentItem[], incoming: ContentItem[]): ContentItem[] {
  const result = existing.map(c => ({ ...c }));
  for (const add of incoming) {
    const match = result.find(c => c.chemId === add.chemId && c.phase === add.phase);
    if (match) match.amountMl += add.amountMl;
    else result.push({ ...add });
  }
  return result;
}

// ─── Generic colour blending (fallback for combinations with no named rule) ───

function parseColor(input: string): { r: number; g: number; b: number; a: number } {
  const rgbaMatch = input.match(/rgba?\(([^)]+)\)/);
  if (rgbaMatch) {
    const parts = rgbaMatch[1].split(",").map(s => parseFloat(s.trim()));
    return { r: parts[0] ?? 255, g: parts[1] ?? 255, b: parts[2] ?? 255, a: parts[3] ?? 1 };
  }
  const hex = input.replace("#", "");
  if (hex.length === 6) {
    return {
      r: parseInt(hex.slice(0, 2), 16),
      g: parseInt(hex.slice(2, 4), 16),
      b: parseInt(hex.slice(4, 6), 16),
      a: 1,
    };
  }
  return { r: 200, g: 220, b: 240, a: 0.3 };
}

function blendContentColors(contents: ContentItem[]): string {
  let rSum = 0, gSum = 0, bSum = 0, aSum = 0, wSum = 0;
  for (const c of contents) {
    const item = getItem(c.chemId);
    const swatch = item?.liquidColor || (c.phase === "solid" ? "#E2E8F0" : "rgba(186,230,253,0.2)");
    const { r, g, b, a } = parseColor(swatch);
    const w = Math.max(1, c.amountMl);
    rSum += r * w; gSum += g * w; bSum += b * w; aSum += a * w; wSum += w;
  }
  if (wSum === 0) return "rgba(186,230,253,0.12)";
  const r = Math.round(rSum / wSum), g = Math.round(gSum / wSum), b = Math.round(bSum / wSum);
  const a = Math.min(0.9, Math.max(0.15, aSum / contents.length));
  return `rgba(${r},${g},${b},${a})`;
}

function lerp(a: number, b: number, t: number): number { return a + (b - a) * t; }

function lerpColor(c1: string, c2: string, t: number): string {
  const p1 = parseColor(c1), p2 = parseColor(c2);
  const r = Math.round(lerp(p1.r, p2.r, t)), g = Math.round(lerp(p1.g, p2.g, t)), b = Math.round(lerp(p1.b, p2.b, t));
  const a = lerp(p1.a, p2.a, t);
  return `rgba(${r},${g},${b},${a.toFixed(2)})`;
}

function clamp01(x: number): number { return Math.min(1, Math.max(0, x)); }

export function computeFillColor(contents: ContentItem[]): string {
  if (contents.length === 0) return "rgba(186,230,253,0.08)";
  const ids = contents.map(c => c.chemId);

  // KMnO₄ — dominant purple
  if (ids.includes("kmno4")) {
    const hasReductant = ids.some(i => ["mohrs_salt", "oxalic_acid", "na2c2o4", "feso4_mohrs"].includes(i));
    return hasReductant ? "rgba(209,250,229,0.5)" : "#9333EA";
  }
  // CuSO₄ + NaOH/NH₄OH → blue precipitate
  if (ids.includes("cuso4") && ids.some(i => ["naoh", "nh4oh"].includes(i))) return "#93C5FD";
  if (ids.includes("cuso4")) return "#3B82F6";
  // FeCl₃ — amber
  if (ids.includes("fecl3")) {
    if (ids.some(i => ["k4fecn6", "naoh", "nh4oh"].includes(i))) return "#92400E";
    return "#B45309";
  }
  // Co(NO₃)₂ — pink
  if (ids.includes("co_no3")) return "#F472B6";
  // NiSO₄ — green
  if (ids.includes("niso4")) return "#16A34A";
  // K₂Cr₂O₇ — orange
  if (ids.includes("k2cr2o7")) return "#EA580C";
  // Na₂S — pale yellow
  if (ids.includes("na2s")) return "#FDE68A";
  // AgNO₃ + halide → white precipitate
  if (ids.includes("agno3") && ids.some(i => ["hcl_dil", "nacl", "ki"].includes(i))) return "#F8FAFC";
  // BaCl₂ + SO₄ → white precipitate
  if (ids.includes("bacl2") && ids.some(i => ["h2so4_dil", "na2so3"].includes(i))) return "#F8FAFC";
  // KI + oxidant → iodine (brown/yellow with starch → blue)
  if (ids.includes("ki") && ids.includes("starch_soln")) return "#312E81";
  // Mohr's salt — pale green
  if (ids.includes("mohrs_salt")) return "#A7F3D0";
  // Lime water + CO₂ → milky
  if (ids.includes("lime_water")) return "rgba(241,245,249,0.85)";

  // Acid-base indicators — colour fades continuously with pH instead of
  // flipping instantly, so the colour change on reaching the endpoint reads
  // as a gradual titration rather than a hard switch.
  const ph = estimatePh(contents);
  if (ids.includes("phenol")) {
    const t = clamp01((ph - 8.0) / 1.2); // 0 = colourless, 1 = full pink
    return lerpColor("rgba(255,255,255,0.10)", "rgba(244,114,182,0.55)", t);
  }
  if (ids.includes("methyl_orange")) {
    const t = clamp01((ph - 3.1) / 1.3); // 0 = red, 1 = yellow
    return lerpColor("rgba(252,165,165,0.6)", "rgba(253,230,138,0.55)", t);
  }
  if (ids.includes("litmus_soln")) {
    const t = clamp01((ph - 6) / 2); // 0 = red, 1 = blue
    return lerpColor("rgba(252,165,165,0.55)", "rgba(147,197,253,0.55)", t);
  }

  // Water / acids / bases — pale
  if (ids.length === 1 && ids.some(i => ["water", "hcl_dil", "h2so4_dil"].includes(i))) return "rgba(186,230,253,0.18)";
  // Fallback: blend whatever real colours the placed chemicals carry, so every
  // combination shows *something* derived from what's actually in the vessel.
  return blendContentColors(contents);
}

export function computeFillLevel(contents: ContentItem[]): number {
  if (contents.length === 0) return 0;
  const total = contents.reduce((s, c) => s + c.amountMl, 0);
  return Math.min(0.85, total / 300);
}

export function computeLabel(contents: ContentItem[]): string {
  if (contents.length === 0) return "(empty)";
  return contents
    .map(c => `${getItem(c.chemId)?.name ?? c.chemId} (${c.phase}, ${Math.round(c.amountMl)}ml)`)
    .join(" + ");
}

// Rough pH estimate driven by how much acid vs. base is actually in the
// vessel (weighted by amount, not just "is it present"), so pH moves
// gradually toward neutral as a titration proceeds instead of jumping
// between a few fixed values.
const ACID_EQ: Record<string, number> = {
  hcl_dil: 1, hcl_conc: 4, h2so4_dil: 2, h2so4_conc: 8,
  hno3_dil: 1, hno3_conc: 4, oxalic_acid: 1,
};
const BASE_EQ: Record<string, number> = {
  naoh: 1, koh: 1, nh4oh: 0.3, lime_water: 0.05, caoh2: 2, na2co3: 1,
};

export function estimatePh(contents: ContentItem[]): number {
  if (contents.length === 0) return 7;
  let acidEq = 0, baseEq = 0;
  for (const c of contents) {
    if (c.chemId in ACID_EQ) acidEq += c.amountMl * ACID_EQ[c.chemId];
    if (c.chemId in BASE_EQ) baseEq += c.amountMl * BASE_EQ[c.chemId];
  }
  if (acidEq === 0 && baseEq === 0) return 7;
  const net = baseEq - acidEq;
  // Transition width scales with how much acid/base is actually in play, so
  // a small trial and a large one both show a sensible-looking fade.
  const scale = Math.max(2, (baseEq || acidEq) * 0.12);
  return 7 + 6.9 * Math.tanh(net / scale);
}

// ─── Initial AI chat (no hardcoded scenario) ──────────────────────────────────

export interface ChatMsg {
  role: "assistant" | "user";
  text: string;
  time: string;
}

export const INITIAL_CHAT: ChatMsg[] = [
  {
    role: "assistant",
    text: "Hello! I'm your AI Lab Assistant. Drag chemicals and apparatus from the panel on the left onto the bench to begin. I'll explain every reaction as you work.",
    time: "—",
  },
];

// ─── Guided experiments (for reference, no forced mode) ──────────────────────

export const GUIDED_EXPERIMENTS = [
  { id: "titration", title: "Acid-Base Titration", desc: "Titrate HCl with standard Na₂CO₃ using methyl orange indicator", difficulty: "Standard", time: "45 min" },
  { id: "redox", title: "Redox Titration (KMnO₄)", desc: "Standardise Mohr's salt or oxalic acid against KMnO₄", difficulty: "Advanced", time: "50 min" },
  { id: "salt_analysis", title: "Salt Analysis", desc: "Identify an unknown salt using the group scheme", difficulty: "Standard", time: "60 min" },
  { id: "flame_test", title: "Flame Test", desc: "Identify cations from their characteristic flame colours", difficulty: "Beginner", time: "20 min" },
];
