import {
  useState, useRef, useCallback, useEffect,
  type DragEvent, type PointerEvent, type WheelEvent,
  type MouseEvent as RMouseEvent,
} from "react";
import {
  APPARATUS_GROUPS, CHEMICAL_GROUPS, ALL_ITEMS,
  computeFillColor, computeFillLevel, computeLabel, estimatePh, mergeContents,
  INITIAL_CHAT, type LabItem, type ContentItem, type ChatMsg,
} from "./data";

// Approximate on-canvas footprint of a placed apparatus, used for hit-testing
// (which apparatus is under the pointer) when dropping a chemical or pouring.
const APPARATUS_BOX = { w: 100, h: 130 };

// ─── Types ────────────────────────────────────────────────────────────────────

interface CanvasItem {
  cid: string;
  labItemId: string;
  x: number;
  y: number;
  contents: ContentItem[];
  rotation: number;
}

interface Bench {
  id: string;
  name: string;
  items: CanvasItem[];
}

interface CtxMenu {
  x: number; y: number;
  type: "canvas" | "item";
  cid?: string;
}

interface PendingDrop {
  item: LabItem;
  x: number; y: number;       // canvas-space coords (where it lands)
  screenX: number; screenY: number; // for popover placement
  targetCid: string | null;   // apparatus already on the bench to fill, if any
}

interface Titration {
  buretteCid: string;
  targetCid: string;
  dropsPerSec: number;
  active: boolean;
  dispensedMl: number;
}

interface NotebookRow {
  trial: number;
  volume: number;
  observation: string;
  result: string;
}

// ─── Chemistry SVG apparatus ──────────────────────────────────────────────────

function FlaskSVG({ fill, level, narrow }: { fill: string; level: number; narrow?: boolean }) {
  const bw = narrow ? 60 : 84;
  const bx = narrow ? 20 : 8;
  return (
    <svg viewBox="0 0 100 120" className="w-20 h-24 drop-shadow-sm">
      <rect x="38" y="4" width="24" height="30" rx="3" fill="white" stroke="#94A3B8" strokeWidth="1.5" />
      <path d={`M38,34 L${bx},110 L${100-bx},110 Z`} fill="white" stroke="#94A3B8" strokeWidth="1.5" strokeLinejoin="round" />
      <clipPath id={`fc-${bw}`}><path d={`M38,34 L${bx},110 L${100-bx},110 Z`} /></clipPath>
      {level > 0 && <rect x="0" y={34 + 76*(1-level)} width="100" height={76*level+10} fill={fill} opacity="0.8" clipPath={`url(#fc-${bw})`} />}
      <path d="M48,45 L52,95" stroke="white" strokeWidth="1.5" opacity="0.4" strokeLinecap="round" />
    </svg>
  );
}

function BeakerSVG({ fill, level }: { fill: string; level: number }) {
  return (
    <svg viewBox="0 0 100 110" className="w-20 h-22 drop-shadow-sm">
      <path d="M12,8 L88,8 L94,102 L6,102 Z" fill="white" stroke="#94A3B8" strokeWidth="1.5" strokeLinejoin="round" />
      <clipPath id="bkc"><path d="M12,8 L88,8 L94,102 L6,102 Z" /></clipPath>
      {level > 0 && <rect x="0" y={8+94*(1-level)} width="100" height={94*level+5} fill={fill} opacity="0.7" clipPath="url(#bkc)" />}
      <path d="M88,8 L96,4" stroke="#94A3B8" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M18,22 L24,22" stroke="#CBD5E1" strokeWidth="1" /><text x="26" y="25" fontSize="6" fill="#94A3B8">50</text>
      <path d="M15,52 L24,52" stroke="#CBD5E1" strokeWidth="1" /><text x="26" y="55" fontSize="6" fill="#94A3B8">150</text>
      <path d="M13,80 L24,80" stroke="#CBD5E1" strokeWidth="1" /><text x="26" y="83" fontSize="6" fill="#94A3B8">250</text>
      <path d="M20,15 L23,90" stroke="white" strokeWidth="2" opacity="0.35" strokeLinecap="round" />
    </svg>
  );
}

function BuretteSVG({ fill, level, dropsPerSec }: { fill: string; level: number; dropsPerSec: number }) {
  const bodyH = 130;
  const fillH = bodyH * level;
  return (
    <svg viewBox="0 0 52 230" className="w-10 h-48 drop-shadow-sm">
      <rect x="5" y="0" width="5" height="210" rx="2" fill="#94A3B8" />
      <rect x="10" y="60" width="14" height="5" rx="2" fill="#64748B" />
      <rect x="22" y="18" width="16" height={bodyH} rx="3" fill="white" stroke="#94A3B8" strokeWidth="1.5" />
      <clipPath id="brtc"><rect x="23" y="19" width="14" height={bodyH-2} rx="2" /></clipPath>
      {level > 0 && <rect x="23" y={19+(bodyH-fillH)} width="14" height={fillH} fill={fill || "#93C5FD"} opacity="0.75" clipPath="url(#brtc)" />}
      {[0.2,0.4,0.6,0.8].map((t,i) => (
        <g key={i}>
          <line x1="22" y1={18+bodyH*t} x2="28" y2={18+bodyH*t} stroke="#CBD5E1" strokeWidth="1" />
          <text x="20" y={21+bodyH*t} fontSize="5" fill="#94A3B8" textAnchor="end">{(i+1)*10}</text>
        </g>
      ))}
      <rect x="26" y={150+18} width="10" height="5" rx="2" fill="#64748B" />
      <rect x="29" y={155+18} width="3" height="18" fill="#94A3B8" />
      {dropsPerSec > 0 && <ellipse cx="30" cy={195} rx="2.5" ry="3.5" fill={fill || "#93C5FD"} opacity="0.85" />}
    </svg>
  );
}

function TestTubeSVG({ fill, level }: { fill: string; level: number }) {
  return (
    <svg viewBox="0 0 40 100" className="w-8 h-20 drop-shadow-sm">
      <rect x="10" y="2" width="20" height="68" rx="2" fill="white" stroke="#94A3B8" strokeWidth="1.5" />
      <path d="M10,70 Q10,90 20,90 Q30,90 30,70" fill="white" stroke="#94A3B8" strokeWidth="1.5" />
      <clipPath id="ttc"><rect x="11" y="3" width="18" height="86" rx="1" /></clipPath>
      {level > 0 && <rect x="11" y={3+87*(1-level)} width="18" height={87*level} fill={fill} opacity="0.75" clipPath="url(#ttc)" />}
    </svg>
  );
}

function GenericApparatusSVG({ item }: { item: LabItem }) {
  return (
    <div className="w-16 h-16 rounded-xl flex items-center justify-center text-[11px] font-bold" style={{ background: item.bgColor, color: item.iconColor }}>
      {item.abbrev}
    </div>
  );
}

function CanvasApparatus({ ci, labItem, isDripping, isPourTarget }: { ci: CanvasItem; labItem: LabItem; isDripping?: boolean; isPourTarget?: boolean }) {
  const fill = computeFillColor(ci.contents);
  const level = computeFillLevel(ci.contents);
  const label = computeLabel(ci.contents);
  const bLevel = labItem.id === "burette" ? Math.max(0.1, 1 - level) : level;

  let svg: React.ReactNode;
  if (labItem.id === "burette") svg = <BuretteSVG fill={fill} level={bLevel} dropsPerSec={isDripping ? 3 : 0} />;
  else if (["conical", "volumetric", "round_flask"].includes(labItem.id)) svg = <FlaskSVG fill={fill} level={level} narrow={labItem.id === "volumetric"} />;
  else if (["beaker", "boiling_tube"].includes(labItem.id)) svg = <BeakerSVG fill={fill} level={level} />;
  else if (labItem.id === "test_tube") svg = <TestTubeSVG fill={fill} level={level} />;
  else svg = <GenericApparatusSVG item={labItem} />;

  return (
    <div
      className="flex flex-col items-center gap-1 select-none rounded-xl transition-shadow"
      style={isPourTarget ? { boxShadow: "0 0 0 3px var(--chem)", background: "var(--chem-muted)" } : undefined}
    >
      {svg}
      <div className="text-[9px] text-center text-slate-500 max-w-[110px] leading-tight bg-white/70 px-1.5 py-0.5 rounded-md">
        <span className="font-semibold text-slate-700">{labItem.name}</span>
        {ci.contents.length > 0 && <><br />{label}</>}
      </div>
    </div>
  );
}

// ─── Add-chemical popover (form, amount, water-to-dissolve) ────────────────────

function AddChemicalPopover({
  drop, onConfirm, onCancel,
}: {
  drop: PendingDrop;
  onConfirm: (contents: ContentItem[]) => void;
  onCancel: () => void;
}) {
  const [phase, setPhase] = useState<"liquid" | "solid">("liquid");
  const [amount, setAmount] = useState(50);
  const [waterAmount, setWaterAmount] = useState(20);
  const item = drop.item;

  // Keep the popover on-screen near the drop point.
  const left = Math.min(Math.max(drop.screenX - 130, 8), window.innerWidth - 268);
  const top = Math.min(drop.screenY + 12, window.innerHeight - 300);

  const confirm = () => {
    const contents: ContentItem[] = phase === "liquid"
      ? [{ chemId: item.id, amountMl: amount, phase: "liquid" }]
      : [
          { chemId: item.id, amountMl: amount, phase: "solid" },
          ...(waterAmount > 0 ? [{ chemId: "water", amountMl: waterAmount, phase: "liquid" as const }] : []),
        ];
    onConfirm(contents);
  };

  return (
    <div className="fixed inset-0 z-[60]" onClick={onCancel}>
      <div
        className="absolute w-64 bg-white rounded-2xl shadow-2xl border border-[var(--border)] p-3.5"
        style={{ left, top }}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-11 h-11 rounded-lg flex items-center justify-center text-[10px] font-bold flex-shrink-0" style={{ background: item.bgColor, color: item.iconColor }}>
            {item.abbrev}
          </div>
          <div className="min-w-0">
            <div className="text-[13px] font-semibold text-[var(--text)] truncate">{item.name}</div>
            {item.formula && <div className="text-[10px] text-[var(--muted)]">{item.formula}</div>}
          </div>
        </div>

        <div className="mb-3">
          <div className="text-[9px] font-bold text-[var(--muted)] uppercase tracking-widest mb-1.5">Form</div>
          <div className="flex gap-1.5">
            {(["liquid", "solid"] as const).map(p => (
              <button
                key={p}
                onClick={() => setPhase(p)}
                className={`flex-1 py-1.5 rounded-lg text-[11px] font-medium capitalize transition-colors ${phase === p ? "bg-[var(--chem)] text-white" : "bg-slate-100 text-[var(--muted)] hover:bg-slate-200"}`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-3">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[9px] font-bold text-[var(--muted)] uppercase tracking-widest">{phase === "liquid" ? "Amount" : "Amount (solid)"}</span>
            <span className="text-[11px] font-mono font-semibold text-[var(--text)]">{amount}ml</span>
          </div>
          <input type="range" min={5} max={250} step={5} value={amount} onChange={e => setAmount(Number(e.target.value))} className="w-full accent-[var(--chem)]" />
        </div>

        {phase === "solid" && (
          <div className="mb-3.5">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[9px] font-bold text-[var(--muted)] uppercase tracking-widest">Dissolve in water</span>
              <span className="text-[11px] font-mono font-semibold text-[var(--text)]">{waterAmount}ml</span>
            </div>
            <input type="range" min={0} max={200} step={5} value={waterAmount} onChange={e => setWaterAmount(Number(e.target.value))} className="w-full accent-[var(--chem)]" />
            <div className="text-[9px] text-[var(--muted)] mt-1">More water = more dilute solution.</div>
          </div>
        )}

        <div className="flex gap-2">
          <button onClick={onCancel} className="flex-1 py-1.5 rounded-lg text-[11px] font-medium bg-slate-100 text-[var(--muted)] hover:bg-slate-200 transition-colors">Cancel</button>
          <button onClick={confirm} className="flex-1 py-1.5 rounded-lg text-[11px] font-semibold bg-[var(--chem)] text-white hover:bg-[var(--chem-hover)] transition-colors">Add to bench</button>
        </div>
      </div>
    </div>
  );
}

// ─── Sidebar grid item ─────────────────────────────────────────────────────────

function GridItem({ item, onDragStart }: { item: LabItem; onDragStart: (e: DragEvent<HTMLDivElement>, item: LabItem) => void }) {
  return (
    <div
      className="sidebar-item flex flex-col items-center gap-0.5 p-1 rounded-lg hover:bg-slate-100 transition-colors"
      draggable
      onDragStart={(e) => onDragStart(e, item)}
      title={item.name + (item.formula ? ` (${item.formula})` : "")}
    >
      <div
        className="w-[60px] h-[40px] rounded-lg flex items-center justify-center text-[9px] font-bold text-center px-1 leading-tight"
        style={{ background: item.bgColor, color: item.iconColor }}
      >
        {item.abbrev}
      </div>
      <span className="text-[8.5px] text-slate-500 text-center leading-tight w-[60px] truncate">{item.name}</span>
    </div>
  );
}

// ─── Toggle switch ─────────────────────────────────────────────────────────────

function Toggle({ on, onChange, color = "#059669" }: { on: boolean; onChange: (v: boolean) => void; color?: string }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="relative w-9 h-5 rounded-full transition-colors duration-200 flex-shrink-0"
      style={{ background: on ? color : "#CBD5E1" }}
    >
      <span
        className="absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform duration-200"
        style={{ transform: on ? "translateX(16px)" : "translateX(0)" }}
      />
    </button>
  );
}

// ─── Dropdown menu ─────────────────────────────────────────────────────────────

const MENUS: Record<string, (string | "---")[]> = {
  Experiment: ["New Experiment", "Save Online", "Save Offline", "Open Offline", "Export as File", "Import File", "---", "Clear Bench", "Recover Experiment", "---", "Preview Bench"],
  Tools: ["Concentration/Molarity Converter", "Download Image", "---", "Themes", "Custom Shortcuts"],
  Help: ["Tutorial Guide", "User Manual", "Learn Chemistry Basics", "---", "Discussion Forum"],
};

function TopMenuBar({
  onBack, benchName, openMenu, setOpenMenu, onClearBench,
}: {
  onBack: () => void;
  benchName: string;
  openMenu: string | null;
  setOpenMenu: (m: string | null) => void;
  onClearBench: () => void;
}) {
  return (
    <header className="flex-none flex items-center h-10 border-b border-[var(--border)] bg-white px-3 gap-1 z-40 select-none" onClick={e => e.stopPropagation()}>
      <button onClick={onBack} className="flex items-center gap-1.5 mr-2">
        <div className="w-6 h-6 rounded-md bg-[var(--chem)] flex items-center justify-center">
          <svg viewBox="0 0 16 16" className="w-3 h-3 fill-white"><path d="M5 2h6v5l3 7H2l3-7V2z" /></svg>
        </div>
        <span className="text-[11px] font-semibold text-[var(--text)] hidden sm:block">OES</span>
      </button>

      {Object.keys(MENUS).map(label => (
        <div key={label} className="relative">
          <button
            onClick={() => setOpenMenu(openMenu === label ? null : label)}
            className={`text-[12px] px-2.5 py-1 rounded-md transition-colors ${openMenu === label ? "bg-slate-100 text-[var(--text)]" : "text-[var(--muted)] hover:text-[var(--text)] hover:bg-slate-50"}`}
          >
            {label} <span className="text-[9px]">▾</span>
          </button>
          {openMenu === label && (
            <div className="dropdown-menu">
              {MENUS[label].map((item, i) => {
                if (item === "---") return <div key={i} className="dropdown-sep" />;
                const wired = item === "Clear Bench";
                return (
                  <button
                    key={item}
                    className={`dropdown-item ${wired ? "" : "opacity-45 cursor-not-allowed"}`}
                    onClick={() => { setOpenMenu(null); if (wired) onClearBench(); }}
                  >
                    {item}{!wired && <span className="text-[9px] ml-1.5 text-[var(--muted)]">soon</span>}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      ))}

      <div className="flex-1 text-center">
        <span className="text-[12px] font-medium text-[var(--muted)]">{benchName}</span>
      </div>

      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-0.5">
          <button className="text-[10px] font-semibold px-2.5 py-1 rounded-md bg-white shadow-sm text-[var(--chem)]">Chemistry</button>
          <button className="text-[10px] font-medium px-2.5 py-1 rounded-md text-[var(--muted)] flex items-center gap-1">
            Physics <span className="text-[8px] bg-[var(--phys-light)] text-[var(--phys)] px-1 py-px rounded-full font-semibold">Soon</span>
          </button>
        </div>
        <button className="text-[11px] px-2.5 py-1 border border-[var(--border)] rounded-lg hover:bg-slate-50 transition-colors text-[var(--muted)]">Sign in</button>
        <div className="w-6 h-6 rounded-full bg-[var(--chem-muted)] flex items-center justify-center text-[9px] font-bold text-[var(--chem)]">S</div>
      </div>
    </header>
  );
}

// ─── Tab strip ─────────────────────────────────────────────────────────────────

function TabStrip({
  benches, active, onSwitch, onAdd, onClose,
}: {
  benches: Bench[]; active: string;
  onSwitch: (id: string) => void;
  onAdd: () => void;
  onClose: (id: string) => void;
}) {
  return (
    <div className="flex-none flex items-center h-8 border-b border-[var(--border)] bg-white px-2 gap-0.5">
      {benches.map(b => (
        <div
          key={b.id}
          onClick={() => onSwitch(b.id)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-t-lg text-[11px] cursor-pointer transition-colors border-b-2 ${b.id === active
            ? "border-[var(--chem)] text-[var(--text)] font-semibold bg-[var(--chem-muted)]"
            : "border-transparent text-[var(--muted)] hover:text-[var(--text)] hover:bg-slate-50"
          }`}
        >
          {b.name}
          {benches.length > 1 && (
            <button
              onClick={e => { e.stopPropagation(); onClose(b.id); }}
              className="w-3.5 h-3.5 rounded-full hover:bg-slate-200 flex items-center justify-center text-[8px] text-slate-400 hover:text-slate-600"
            >×</button>
          )}
        </div>
      ))}
      <button
        onClick={onAdd}
        className="w-6 h-6 rounded-md hover:bg-slate-100 flex items-center justify-center text-[var(--muted)] hover:text-[var(--text)] transition-colors ml-1"
      >+</button>
    </div>
  );
}

// ─── Left panel ────────────────────────────────────────────────────────────────

function LeftPanel({
  open, onToggle, searchQ, setSearchQ,
  onDragStart,
}: {
  open: boolean; onToggle: () => void;
  searchQ: string; setSearchQ: (s: string) => void;
  onDragStart: (e: DragEvent<HTMLDivElement>, item: LabItem) => void;
}) {
  const [expanded, setExpanded] = useState<string[]>(["glassware", "acids", "bases"]);

  const toggle = (id: string) =>
    setExpanded(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const allGroups = [...APPARATUS_GROUPS, ...CHEMICAL_GROUPS];
  const q = searchQ.toLowerCase();

  const filtered = allGroups.map(g => ({
    ...g,
    items: q ? g.items.filter(i => i.name.toLowerCase().includes(q) || (i.formula || "").toLowerCase().includes(q)) : g.items,
  })).filter(g => g.items.length > 0);

  return (
    <aside
      className="flex-none bg-white border-r border-[var(--border)] flex flex-col overflow-hidden transition-all duration-200"
      style={{ width: open ? "245px" : "36px" }}
      onClick={e => e.stopPropagation()}
    >
      {open ? (
        <>
          <div className="flex items-center justify-between px-3 pt-2.5 pb-1">
            <span className="text-[10px] font-bold text-[var(--text)] tracking-widest uppercase">Lab Elements</span>
            <button onClick={onToggle} className="p-1 rounded hover:bg-slate-100 text-[var(--muted)]" title="Collapse">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="2"/><line x1="9" y1="3" x2="9" y2="21" strokeWidth="2"/></svg>
            </button>
          </div>

          <div className="px-2 pb-2">
            <div className="flex items-center gap-1.5 bg-slate-50 border border-[var(--border)] rounded-lg px-2.5 py-1.5">
              <svg className="w-3 h-3 text-[var(--muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8" strokeWidth="2"/><path d="M21 21l-4.35-4.35" strokeWidth="2" strokeLinecap="round"/></svg>
              <input type="text" placeholder="Search.." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                className="bg-transparent text-[11px] text-[var(--text)] placeholder-[var(--muted)] outline-none w-full" />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto pb-3">
            {filtered.map(g => (
              <div key={g.id}>
                <button
                  onClick={() => toggle(g.id)}
                  className="flex items-center gap-1.5 w-full px-3 py-1.5 hover:bg-slate-50 transition-colors"
                >
                  <svg className={`w-2.5 h-2.5 text-[var(--muted)] transition-transform flex-shrink-0 ${expanded.includes(g.id) ? "rotate-90" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7"/></svg>
                  <span className="text-[10px] font-semibold text-[var(--muted)] uppercase tracking-wide">{g.label}</span>
                  <span className="ml-auto text-[9px] text-[var(--muted)] bg-slate-100 px-1.5 py-px rounded">{g.items.length}</span>
                </button>
                {(expanded.includes(g.id) || q) && (
                  <div className="grid grid-cols-3 gap-0.5 px-2 pb-1">
                    {g.items.map(item => <GridItem key={item.id} item={item} onDragStart={onDragStart} />)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center pt-2">
          <button onClick={onToggle} className="p-1.5 rounded hover:bg-slate-100 text-[var(--muted)]" title="Expand panel">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="2"/><line x1="15" y1="3" x2="15" y2="21" strokeWidth="2"/></svg>
          </button>
          <div className="text-[8px] text-[var(--muted)] mt-2 [writing-mode:vertical-lr] tracking-widest">LAB ELEMENTS</div>
        </div>
      )}
    </aside>
  );
}

// ─── Floating toolbar ──────────────────────────────────────────────────────────

function FloatingToolbar({
  zoom, onZoom, isPlaying, onPlayPause, onClearBench, onUndo, onRedo,
}: {
  zoom: number; onZoom: (z: number) => void;
  isPlaying: boolean; onPlayPause: () => void;
  onClearBench: () => void;
  onUndo: () => void; onRedo: () => void;
}) {
  const btn = "w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-200 hover:text-slate-700 transition-colors";
  const zPercent = Math.round(zoom * 100);

  return (
    <div className="absolute top-2 left-1/2 -translate-x-1/2 z-20 flex items-center gap-0.5 bg-white border border-[var(--border)] rounded-xl shadow-md px-1.5 py-1" onClick={e => e.stopPropagation()}>
      {/* Drag handle visual */}
      <div className="w-5 h-7 flex items-center justify-center text-slate-300 cursor-move mr-0.5">
        <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 16 16">
          <circle cx="5" cy="4" r="1.3"/><circle cx="11" cy="4" r="1.3"/>
          <circle cx="5" cy="8" r="1.3"/><circle cx="11" cy="8" r="1.3"/>
          <circle cx="5" cy="12" r="1.3"/><circle cx="11" cy="12" r="1.3"/>
        </svg>
      </div>
      <div className="w-px h-5 bg-slate-200 mx-0.5" />
      <button className={`${btn} opacity-40 cursor-not-allowed`} title="Save (coming soon)" disabled><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"/></svg></button>
      <button className={btn} title="Clear Bench" onClick={onClearBench}><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg></button>
      <button className={`${btn} opacity-40 cursor-not-allowed`} title="Export Image (coming soon)" disabled><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="2"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.5 14l3-3 3 3M12 11v7"/></svg></button>
      <div className="w-px h-5 bg-slate-200 mx-0.5" />
      <button className={`${btn} opacity-40 cursor-not-allowed`} title="Undo (coming soon)" disabled onClick={onUndo}><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 14L4 9l5-5"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 9h10a6 6 0 010 12h-1"/></svg></button>
      <button className={`${btn} opacity-40 cursor-not-allowed`} title="Redo (coming soon)" disabled onClick={onRedo}><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 14l5-5-5-5"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 9H10a6 6 0 000 12h1"/></svg></button>
      <div className="w-px h-5 bg-slate-200 mx-0.5" />
      {/* Play/Pause — spacebar shortcut */}
      <button
        className={`${btn} ${isPlaying ? "bg-[var(--chem-muted)] text-[var(--chem)] hover:bg-[var(--chem-light)]" : ""}`}
        title="Play/Pause simulation (Space)"
        onClick={onPlayPause}
      >
        {isPlaying
          ? <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>
          : <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
        }
      </button>
      <button
        className={btn} title="Fullscreen"
        onClick={() => { if (!document.fullscreenElement) document.documentElement.requestFullscreen?.(); else document.exitFullscreen?.(); }}
      ><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"/></svg></button>
      <div className="w-px h-5 bg-slate-200 mx-0.5" />
      {/* Zoom controls */}
      <button className={btn} onClick={() => onZoom(Math.max(0.3, zoom - 0.1))}>−</button>
      <input
        type="range" min={30} max={200} value={zPercent}
        onChange={e => onZoom(Number(e.target.value) / 100)}
        className="w-20 accent-[var(--chem)]"
      />
      <button className={btn} onClick={() => onZoom(Math.min(2, zoom + 0.1))}>+</button>
      <span className="text-[10px] font-mono text-[var(--muted)] w-8 text-center">{zPercent}%</span>
    </div>
  );
}

// ─── Right panel ────────────────────────────────────────────────────────────────

function RightPanel({
  open, onToggle,
  expName, setExpName, benchName, setBenchName,
  reactionSpeed, setReactionSpeed,
  liveSimulation, setLiveSimulation,
  liteMode, setLiteMode,
  onSave, onClearBench,
  chat, chatInput, setChatInput, onSendChat,
  selectedBurette, otherApparatus, titration, onStartTitration, onStopTitration,
}: {
  open: boolean; onToggle: () => void;
  expName: string; setExpName: (s: string) => void;
  benchName: string; setBenchName: (s: string) => void;
  reactionSpeed: number; setReactionSpeed: (n: number) => void;
  liveSimulation: boolean; setLiveSimulation: (b: boolean) => void;
  liteMode: boolean; setLiteMode: (b: boolean) => void;
  onSave: () => void; onClearBench: () => void;
  chat: ChatMsg[]; chatInput: string; setChatInput: (s: string) => void; onSendChat: () => void;
  selectedBurette: CanvasItem | null;
  otherApparatus: { cid: string; name: string }[];
  titration: Titration | null;
  onStartTitration: (buretteCid: string, targetCid: string, dropsPerSec: number) => void;
  onStopTitration: () => void;
}) {
  const [titrateTarget, setTitrateTarget] = useState("");
  const [dripRate, setDripRate] = useState(3);
  const isThisBuretteActive = !!(titration?.active && selectedBurette && titration.buretteCid === selectedBurette.cid);
  const chatEndRef = useRef<HTMLDivElement>(null);
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [chat]);

  const fieldCls = "w-full text-[11px] bg-white border border-[var(--border)] rounded-lg px-2.5 py-1.5 outline-none focus:border-[var(--chem)] text-[var(--text)] transition-colors";

  return (
    <aside
      className="flex-none bg-white border-l border-[var(--border)] flex flex-col overflow-hidden transition-all duration-200"
      style={{ width: open ? "248px" : "36px" }}
      onClick={e => e.stopPropagation()}
    >
      {open ? (
        <>
          {/* PROPERTIES header */}
          <div className="flex items-center justify-between px-3 pt-2.5 pb-1 border-b border-[var(--border)]">
            <span className="text-[10px] font-bold text-[var(--text)] tracking-widest uppercase">Properties</span>
            <button onClick={onToggle} className="p-1 rounded hover:bg-slate-100 text-[var(--muted)]">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="2"/><line x1="15" y1="3" x2="15" y2="21" strokeWidth="2"/></svg>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {/* Experiment Properties */}
            <div className="p-3 border-b border-[var(--border)]">
              <div className="text-[9px] font-bold text-[var(--muted)] uppercase tracking-widest mb-3">Experiment Properties</div>

              <div className="space-y-2.5">
                <div>
                  <label className="text-[10px] font-medium text-[var(--muted)] mb-1 block">Experiment</label>
                  <input value={expName} onChange={e => setExpName(e.target.value)} className={fieldCls} />
                </div>
                <div>
                  <label className="text-[10px] font-medium text-[var(--muted)] mb-1 block">Bench Name</label>
                  <input value={benchName} onChange={e => setBenchName(e.target.value)} className={fieldCls} />
                </div>

                <div>
                  <label className="text-[10px] font-medium text-[var(--muted)] mb-1.5 block">Reaction Speed (ms)</label>
                  <div className="flex items-center gap-2">
                    <button onClick={() => setReactionSpeed(Math.max(100, reactionSpeed - 100))}
                      className="w-6 h-6 rounded border border-[var(--border)] flex items-center justify-center text-[var(--muted)] hover:bg-slate-50 text-sm">−</button>
                    <span className="flex-1 text-center text-[11px] font-mono text-[var(--text)] border border-[var(--border)] rounded-lg py-1">{reactionSpeed}</span>
                    <button onClick={() => setReactionSpeed(Math.min(2000, reactionSpeed + 100))}
                      className="w-6 h-6 rounded border border-[var(--border)] flex items-center justify-center text-[var(--muted)] hover:bg-slate-50 text-sm">+</button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[var(--text)]">Live Simulation</span>
                  <Toggle on={liveSimulation} onChange={setLiveSimulation} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-[var(--text)]">Lite Mode</span>
                  <Toggle on={liteMode} onChange={setLiteMode} color="#94A3B8" />
                </div>
              </div>

              <div className="mt-4 flex flex-col gap-2">
                <button onClick={onSave}
                  className="w-full py-2 rounded-xl bg-[var(--chem)] text-white text-[12px] font-semibold hover:bg-[var(--chem-hover)] transition-colors">
                  Save Layout
                </button>
                <button onClick={onClearBench}
                  className="w-full py-2 rounded-xl bg-rose-500 text-white text-[12px] font-semibold hover:bg-rose-600 transition-colors">
                  Clear Bench
                </button>
              </div>
            </div>

            {/* Titration Control — only shown when a burette with contents is selected */}
            {selectedBurette && selectedBurette.contents.length > 0 && (
              <div className="p-3 border-b border-[var(--border)]">
                <div className="text-[9px] font-bold text-[var(--muted)] uppercase tracking-widest mb-3">Titration Control</div>
                <div className="space-y-2.5">
                  <div>
                    <label className="text-[10px] font-medium text-[var(--muted)] mb-1 block">Titrate into</label>
                    <select
                      value={titrateTarget}
                      onChange={e => setTitrateTarget(e.target.value)}
                      disabled={isThisBuretteActive}
                      className="w-full text-[11px] bg-white border border-[var(--border)] rounded-lg px-2.5 py-1.5 outline-none focus:border-[var(--chem)] text-[var(--text)]"
                    >
                      <option value="">Select a vessel…</option>
                      {otherApparatus.map(a => <option key={a.cid} value={a.cid}>{a.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-medium text-[var(--muted)]">Drip rate</span>
                      <span className="text-[11px] font-mono text-[var(--text)]">{isThisBuretteActive ? titration!.dropsPerSec : dripRate} drops/s</span>
                    </div>
                    <input
                      type="range" min={1} max={10} value={isThisBuretteActive ? titration!.dropsPerSec : dripRate}
                      disabled={isThisBuretteActive}
                      onChange={e => setDripRate(Number(e.target.value))}
                      className="w-full accent-[var(--chem)]"
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-[var(--muted)]">Volume dispensed</span>
                    <span className="font-mono font-semibold text-[var(--text)]">{isThisBuretteActive ? titration!.dispensedMl : 0}ml</span>
                  </div>
                  {isThisBuretteActive ? (
                    <button onClick={onStopTitration} className="w-full py-2 rounded-xl bg-rose-500 text-white text-[12px] font-semibold hover:bg-rose-600 transition-colors">Stop Titration</button>
                  ) : (
                    <button
                      disabled={!titrateTarget}
                      onClick={() => titrateTarget && onStartTitration(selectedBurette.cid, titrateTarget, dripRate)}
                      className="w-full py-2 rounded-xl bg-[var(--chem)] text-white text-[12px] font-semibold hover:bg-[var(--chem-hover)] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      Start Titration
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* AI Assistant */}
            <div className="flex flex-col">
              <div className="flex items-center gap-2 px-3 py-2 border-b border-[var(--border)]">
                <div className="w-5 h-5 rounded-full bg-[var(--chem-muted)] flex items-center justify-center flex-shrink-0">
                  <svg className="w-3 h-3 text-[var(--chem)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                </div>
                <span className="text-[10px] font-bold text-[var(--text)] uppercase tracking-wide">AI Lab Assistant</span>
                <span className="ml-auto flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[var(--chem)] live-dot" /><span className="text-[9px] text-[var(--muted)]">Active</span></span>
              </div>

              <div className="h-52 overflow-y-auto p-2.5 space-y-3">
                {chat.map((msg, i) => {
                  const isAI = msg.role === "assistant";
                  const lines = msg.text.split("\n");
                  return (
                    <div key={i} className={`flex gap-2 ${isAI ? "" : "flex-row-reverse"}`}>
                      {isAI && <div className="w-5 h-5 rounded-full bg-[var(--chem-muted)] flex items-center justify-center flex-shrink-0 mt-0.5">
                        <svg className="w-2.5 h-2.5 text-[var(--chem)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                      </div>}
                      <div className={`rounded-xl px-3 py-2 text-[10px] leading-relaxed max-w-[85%] ${isAI ? "bg-slate-50 border border-[var(--border)] text-[var(--text)] rounded-tl-sm" : "bg-[var(--chem)] text-white rounded-tr-sm"}`}>
                        {lines.map((l, j) => {
                          const html = l.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
                          return <p key={j} className={j > 0 ? "mt-1" : ""} dangerouslySetInnerHTML={{ __html: html || "&nbsp;" }} />;
                        })}
                      </div>
                    </div>
                  );
                })}
                <div ref={chatEndRef} />
              </div>

              <div className="p-2.5 border-t border-[var(--border)]">
                <div className="flex gap-1.5">
                  <textarea
                    rows={2}
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); onSendChat(); }}}
                    placeholder="Ask about this reaction..."
                    className="flex-1 text-[10px] bg-slate-50 border border-[var(--border)] rounded-xl px-2.5 py-1.5 resize-none outline-none focus:border-[var(--chem)] text-[var(--text)] placeholder-[var(--muted)] transition-colors"
                  />
                  <button onClick={onSendChat}
                    className="w-7 h-7 self-end rounded-xl bg-[var(--chem)] flex items-center justify-center text-white hover:bg-[var(--chem-hover)] transition-colors flex-shrink-0">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                  </button>
                </div>
                <div className="flex gap-1 mt-1.5 flex-wrap">
                  {["What's happening?", "Why this colour?", "Next step?"].map(q => (
                    <button key={q} onClick={() => setChatInput(q)}
                      className="text-[9px] bg-[var(--chem-muted)] text-[var(--chem)] px-1.5 py-0.5 rounded-md hover:bg-[var(--chem-light)] transition-colors">{q}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center pt-2 gap-2">
          <button onClick={onToggle} className="p-1.5 rounded hover:bg-slate-100 text-[var(--muted)]">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" strokeWidth="2"/><line x1="9" y1="3" x2="9" y2="21" strokeWidth="2"/></svg>
          </button>
          <div className="text-[8px] text-[var(--muted)] [writing-mode:vertical-lr] tracking-widest">PROPERTIES</div>
        </div>
      )}
    </aside>
  );
}

// ─── Context Menu ──────────────────────────────────────────────────────────────

function ContextMenu({ ctx, onClose, onDelete, onClear }: {
  ctx: CtxMenu; onClose: () => void;
  onDelete: (cid: string) => void; onClear: () => void;
}) {
  const itemCls = "dropdown-item text-[11px]";
  const soonCls = "dropdown-item text-[11px] opacity-45 cursor-not-allowed";
  return (
    <div className="ctx-menu" style={{ left: ctx.x, top: ctx.y }} onMouseLeave={onClose}>
      {ctx.type === "item" && ctx.cid ? (
        <>
          <button className={itemCls} onClick={() => { onDelete(ctx.cid!); onClose(); }}>Delete</button>
          <button className={soonCls} onClick={onClose}>Copy <span className="text-[9px] ml-1 text-[var(--muted)]">soon</span></button>
          <button className={soonCls} onClick={onClose}>Cut <span className="text-[9px] ml-1 text-[var(--muted)]">soon</span></button>
        </>
      ) : (
        <>
          <button className={soonCls} onClick={onClose}>Save Online <span className="text-[9px] ml-1 text-[var(--muted)]">soon</span></button>
          <button className={soonCls} onClick={onClose}>Download Image <span className="text-[9px] ml-1 text-[var(--muted)]">soon</span></button>
          <div className="dropdown-sep" />
          <button className={itemCls} onClick={() => { onClear(); onClose(); }}>Clear Bench</button>
        </>
      )}
    </div>
  );
}

// ─── Main Workspace ────────────────────────────────────────────────────────────

const AI_RESPONSES = [
  "I see you're adding chemicals to the bench. Once you pour a liquid into an apparatus, I'll analyse what's happening in real time.",
  "That's a great combination to explore! Watch the colour of the solution — it tells you about the reaction progress without needing a pH meter.",
  "The precipitate forming is a confirmatory test. In CBSE salt analysis, this observation would go into your Lab Notebook as positive evidence for the ion.",
  "When KMnO₄ changes from purple to colourless, that's the endpoint — the permanganate has been fully reduced. No indicator needed.",
  "Good technique — adding solution drop by drop near the endpoint prevents overshooting. A half-drop difference matters in a precise titration.",
];

export default function Workspace({ onBack }: { onBack: () => void }) {
  const [benches, setBenches] = useState<Bench[]>([{ id: "b1", name: "Bench 1", items: [] }]);
  const [activeBenchId, setActiveBenchId] = useState("b1");

  // UI
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [searchQ, setSearchQ] = useState("");
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [selectedCid, setSelectedCid] = useState<string | null>(null);
  const [ctxMenu, setCtxMenu] = useState<CtxMenu | null>(null);

  // Canvas transform
  const [pan, setPan] = useState({ x: 80, y: 60 });
  const [zoom, setZoom] = useState(1);
  const canvasRef = useRef<HTMLDivElement>(null);
  const panRef = useRef({ isPanning: false, startX: 0, startY: 0, startPanX: 0, startPanY: 0 });

  // Item drag within canvas
  const itemDragRef = useRef<{ cid: string; ox: number; oy: number } | null>(null);

  // Properties
  const [expName, setExpName] = useState("My Experiment");
  const [benchName, setBenchName] = useState("Bench 1");
  const [reactionSpeed, setReactionSpeed] = useState(500);
  const [liveSimulation, setLiveSimulation] = useState(true);
  const [liteMode, setLiteMode] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);

  // AI chat
  const [chat, setChat] = useState<ChatMsg[]>(INITIAL_CHAT);
  const [chatInput, setChatInput] = useState("");
  const aiResponseIdx = useRef(0);

  // Observations
  const [observations, setObservations] = useState<{ label: string; value: string; unit?: string; swatch?: string; color?: string }[]>([]);

  // Add-chemical popover (form / amount / dissolve-water)
  const [pendingDrop, setPendingDrop] = useState<PendingDrop | null>(null);

  // Pour-between-apparatus (drag one item onto another to combine contents)
  const [pourHoverCid, setPourHoverCid] = useState<string | null>(null);

  // Burette titration
  const [titration, setTitration] = useState<Titration | null>(null);

  // Reaction Log (live pH trend) & Lab Notebook (trial table)
  const [showReactionLog, setShowReactionLog] = useState(false);
  const [showNotebook, setShowNotebook] = useState(false);
  const [phLog, setPhLog] = useState<{ t: number; ph: number }[]>([]);
  const [notebook, setNotebook] = useState<NotebookRow[]>([]);

  const activeBench = benches.find(b => b.id === activeBenchId)!;

  const updateItems = useCallback((fn: (items: CanvasItem[]) => CanvasItem[]) => {
    setBenches(prev => prev.map(b => b.id === activeBenchId ? { ...b, items: fn(b.items) } : b));
  }, [activeBenchId]);

  // Update observations whenever canvas items change
  useEffect(() => {
    const items = activeBench.items;
    if (items.length === 0) { setObservations([]); return; }
    const allChemIds = items.flatMap(i => i.contents.map(c => c.chemId));
    const color = computeFillColor(items.flatMap(i => i.contents));
    const obs: typeof observations = [];
    if (allChemIds.includes("kmno4")) obs.push({ label: "Oxidising agent", value: "KMnO₄", color: "#7B2D8B" });
    if (allChemIds.includes("phenol") && allChemIds.some(x => ["naoh", "koh", "na2co3"].includes(x))) {
      obs.push({ label: "Colour", value: "Pink", swatch: "#F9A8D4", color: "#DB2777" });
      obs.push({ label: "pH (est.)", value: "> 8.2", color: "#059669" });
    } else if (allChemIds.some(x => ["hcl_dil", "h2so4_dil"].includes(x))) {
      obs.push({ label: "pH (est.)", value: "~2", color: "#DC2626" });
    }
    if (allChemIds.includes("cuso4") && allChemIds.some(x => ["naoh", "nh4oh"].includes(x))) {
      obs.push({ label: "Precipitate", value: "Cu(OH)₂ — blue", swatch: "#93C5FD", color: "#2563EB" });
    }
    if (allChemIds.includes("agno3") && allChemIds.some(x => ["hcl_dil", "nacl"].includes(x))) {
      obs.push({ label: "Precipitate", value: "AgCl — white", swatch: "#F8FAFC", color: "#64748B" });
    }
    obs.push({ label: "Items on bench", value: `${items.length}`, color: "#64748B" });
    setObservations(obs);

    const ph = estimatePh(items.flatMap(i => i.contents));
    setPhLog(prev => [...prev.slice(-29), { t: Date.now(), ph }]);
  }, [activeBench.items]);

  // ── Hit-testing: which apparatus (if any) sits under a canvas-space point ──
  const apparatusAt = useCallback((cx: number, cy: number, excludeCid?: string): string | null => {
    for (const ci of activeBench.items) {
      if (ci.cid === excludeCid) continue;
      const labItem = ALL_ITEMS.find(i => i.id === ci.labItemId);
      if (!labItem || labItem.category !== "apparatus") continue;
      if (cx >= ci.x && cx <= ci.x + APPARATUS_BOX.w && cy >= ci.y && cy <= ci.y + APPARATUS_BOX.h) return ci.cid;
    }
    return null;
  }, [activeBench.items]);

  // ── Burette titration (drip a controlled amount into a chosen target) ─────
  useEffect(() => {
    if (!titration || !titration.active) return;
    const interval = setInterval(() => {
      setBenches(prevBenches => prevBenches.map(b => {
        if (b.id !== activeBenchId) return b;
        const burette = b.items.find(i => i.cid === titration.buretteCid);
        if (!burette || burette.contents.length === 0) { setTitration(t => t ? { ...t, active: false } : t); return b; }
        const dropMl = 1;
        const liquidIdx = burette.contents.findIndex(c => c.amountMl > 0);
        if (liquidIdx === -1) { setTitration(t => t ? { ...t, active: false } : t); return b; }
        const dispensedContent: ContentItem = { ...burette.contents[liquidIdx], amountMl: Math.min(dropMl, burette.contents[liquidIdx].amountMl) };
        const items = b.items.map(i => {
          if (i.cid === titration.buretteCid) {
            const updated = [...i.contents];
            updated[liquidIdx] = { ...updated[liquidIdx], amountMl: updated[liquidIdx].amountMl - dispensedContent.amountMl };
            return { ...i, contents: updated.filter(c => c.amountMl > 0.01) };
          }
          if (i.cid === titration.targetCid) return { ...i, contents: mergeContents(i.contents, [dispensedContent]) };
          return i;
        });
        return { ...b, items };
      }));
      setTitration(t => t ? { ...t, dispensedMl: t.dispensedMl + 1 } : t);
    }, Math.max(80, 1000 / titration.dropsPerSec));
    return () => clearInterval(interval);
  }, [titration?.active, titration?.dropsPerSec, titration?.buretteCid, titration?.targetCid, activeBenchId]);

  const startTitration = (buretteCid: string, targetCid: string, dropsPerSec: number) =>
    setTitration({ buretteCid, targetCid, dropsPerSec, active: true, dispensedMl: 0 });
  const stopTitration = () => setTitration(t => t ? { ...t, active: false } : null);

  // ── Lab Notebook ────────────────────────────────────────────────────────────
  const saveReading = () => {
    const label = computeLabel(activeBench.items.flatMap(i => i.contents));
    setNotebook(prev => [...prev, {
      trial: prev.length + 1,
      volume: titration?.dispensedMl ?? 0,
      observation: label === "(empty)" ? "No contents on bench" : label,
      result: Math.abs(estimatePh(activeBench.items.flatMap(i => i.contents)) - 7) < 0.6 ? "Equivalence point reached" : "In progress",
    }]);
  };

  // ── Drag from sidebar ──────────────────────────────────────────────────────
  const handleSidebarDragStart = (e: DragEvent<HTMLDivElement>, item: LabItem) => {
    e.dataTransfer.setData("labItemId", item.id);
    e.dataTransfer.effectAllowed = "copy";
  };

  const handleCanvasDragOver = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; };

  const handleCanvasDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const itemId = e.dataTransfer.getData("labItemId");
    const labItem = ALL_ITEMS.find(i => i.id === itemId);
    if (!labItem || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - pan.x) / zoom - 40;
    const y = (e.clientY - rect.top - pan.y) / zoom - 40;

    if (labItem.category === "chemical") {
      // Find the actual apparatus under the drop point (not just "any apparatus
      // that exists somewhere on the bench") so pouring a chemical always fills
      // the vessel the user is actually pointing at.
      const targetCid = apparatusAt(x + 40, y + 40);
      setPendingDrop({ item: labItem, x: Math.max(0, x), y: Math.max(0, y), screenX: e.clientX, screenY: e.clientY, targetCid });
    } else {
      const newItem: CanvasItem = { cid: `c-${Date.now()}`, labItemId: itemId, x: Math.max(0, x), y: Math.max(0, y), contents: [], rotation: 0 };
      updateItems(prev => [...prev, newItem]);
    }
  };

  // Confirm the Add-chemical popover: fills the targeted apparatus, or creates
  // a fresh test tube at the drop point if nothing was under the cursor.
  const confirmPendingDrop = (contents: ContentItem[]) => {
    if (!pendingDrop) return;
    const { item, x, y, targetCid } = pendingDrop;
    if (targetCid) {
      updateItems(prev => prev.map(i => i.cid === targetCid ? { ...i, contents: mergeContents(i.contents, contents) } : i));
      const targetItem = activeBench.items.find(i => i.cid === targetCid);
      const targetName = targetItem ? ALL_ITEMS.find(li => li.id === targetItem.labItemId)?.name : "the vessel";
      triggerAI(`I added ${item.name} to ${targetName}.`);
    } else {
      const ttItem: CanvasItem = { cid: `c-${Date.now()}`, labItemId: "test_tube", x, y, contents, rotation: 0 };
      updateItems(prev => [...prev, ttItem]);
      triggerAI(`I placed ${item.name} in a new test tube.`);
    }
    setPendingDrop(null);
  };

  // ── Canvas pan (background drag) ───────────────────────────────────────────
  const handleCanvasMouseDown = (e: RMouseEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    panRef.current = { isPanning: true, startX: e.clientX, startY: e.clientY, startPanX: pan.x, startPanY: pan.y };
  };

  const handleCanvasMouseMove = useCallback((e: RMouseEvent<HTMLDivElement>) => {
    if (itemDragRef.current && canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left - pan.x) / zoom - itemDragRef.current.ox;
      const y = (e.clientY - rect.top - pan.y) / zoom - itemDragRef.current.oy;
      updateItems(prev => prev.map(i => i.cid === itemDragRef.current!.cid ? { ...i, x: Math.max(0, x), y: Math.max(0, y) } : i));
      // Highlight another apparatus underneath, as a pour target, if this item
      // (or the vessel it's over) actually has something to pour.
      const hover = apparatusAt(x + APPARATUS_BOX.w / 2, y + APPARATUS_BOX.h / 2, itemDragRef.current.cid);
      setPourHoverCid(hover);
      return;
    }
    if (!panRef.current.isPanning) return;
    const dx = e.clientX - panRef.current.startX;
    const dy = e.clientY - panRef.current.startY;
    setPan({ x: panRef.current.startPanX + dx, y: panRef.current.startPanY + dy });
  }, [pan, zoom, updateItems, apparatusAt]);

  const handleCanvasMouseUp = useCallback(() => {
    panRef.current.isPanning = false;
    const draggedCid = itemDragRef.current?.cid;
    if (draggedCid && pourHoverCid && pourHoverCid !== draggedCid) {
      const source = activeBench.items.find(i => i.cid === draggedCid);
      if (source && source.contents.length > 0) {
        updateItems(prev => prev.map(i => {
          if (i.cid === pourHoverCid) return { ...i, contents: mergeContents(i.contents, source.contents) };
          if (i.cid === draggedCid) return { ...i, contents: [] };
          return i;
        }));
        const targetItem = activeBench.items.find(i => i.cid === pourHoverCid);
        const srcName = ALL_ITEMS.find(li => li.id === source.labItemId)?.name ?? "the vessel";
        const tgtName = targetItem ? ALL_ITEMS.find(li => li.id === targetItem.labItemId)?.name : "the vessel";
        triggerAI(`I poured ${srcName} into ${tgtName}.`);
      }
    }
    setPourHoverCid(null);
    itemDragRef.current = null;
  }, [pourHoverCid, activeBench.items, updateItems]);

  const handleWheel = useCallback((e: WheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    const factor = e.deltaY > 0 ? 0.92 : 1.08;
    setZoom(z => Math.min(2, Math.max(0.3, z * factor)));
  }, []);

  // ── Item drag within canvas ────────────────────────────────────────────────
  const handleItemPointerDown = (e: PointerEvent<HTMLDivElement>, cid: string) => {
    e.stopPropagation();
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const ci = activeBench.items.find(i => i.cid === cid)!;
    itemDragRef.current = {
      cid,
      ox: (e.clientX - rect.left - pan.x) / zoom - ci.x,
      oy: (e.clientY - rect.top - pan.y) / zoom - ci.y,
    };
    setSelectedCid(cid);
  };

  // ── Arrow key nudge ────────────────────────────────────────────────────────
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space") { e.preventDefault(); setIsPlaying(p => !p); }
      if (!selectedCid) return;
      const d = e.shiftKey ? 10 : 1;
      if (e.key === "ArrowLeft") updateItems(prev => prev.map(i => i.cid === selectedCid ? { ...i, x: i.x - d } : i));
      if (e.key === "ArrowRight") updateItems(prev => prev.map(i => i.cid === selectedCid ? { ...i, x: i.x + d } : i));
      if (e.key === "ArrowUp") updateItems(prev => prev.map(i => i.cid === selectedCid ? { ...i, y: i.y - d } : i));
      if (e.key === "ArrowDown") updateItems(prev => prev.map(i => i.cid === selectedCid ? { ...i, y: i.y + d } : i));
      if (e.key === "Delete" || e.key === "Backspace") { updateItems(prev => prev.filter(i => i.cid !== selectedCid)); setSelectedCid(null); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selectedCid, updateItems]);

  // ── Context menu ───────────────────────────────────────────────────────────
  const handleContextMenu = (e: RMouseEvent<HTMLDivElement>, type: CtxMenu["type"], cid?: string) => {
    e.preventDefault();
    e.stopPropagation();
    setCtxMenu({ x: e.clientX, y: e.clientY, type, cid });
  };

  // ── Close menu on outside click ────────────────────────────────────────────
  useEffect(() => {
    const close = () => { setOpenMenu(null); setCtxMenu(null); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  // ── AI chat ────────────────────────────────────────────────────────────────
  const triggerAI = (context: string) => {
    const resp = AI_RESPONSES[aiResponseIdx.current % AI_RESPONSES.length];
    aiResponseIdx.current++;
    const now = new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
    setChat(prev => [...prev, { role: "user", text: context, time: now }, { role: "assistant", text: resp, time: now }]);
  };

  const sendChat = () => {
    if (!chatInput.trim()) return;
    const now = new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
    const input = chatInput.trim();
    setChatInput("");
    const resp = AI_RESPONSES[aiResponseIdx.current % AI_RESPONSES.length];
    aiResponseIdx.current++;
    setChat(prev => [...prev, { role: "user", text: input, time: now }, { role: "assistant", text: resp, time: now }]);
  };

  // ── Bench management ───────────────────────────────────────────────────────
  const addBench = () => {
    const id = `b-${Date.now()}`;
    const n = `Bench ${benches.length + 1}`;
    setBenches(prev => [...prev, { id, name: n, items: [] }]);
    setActiveBenchId(id);
    setBenchName(n);
  };

  const closeBench = (id: string) => {
    if (benches.length === 1) return;
    const remaining = benches.filter(b => b.id !== id);
    setBenches(remaining);
    if (activeBenchId === id) setActiveBenchId(remaining[remaining.length - 1].id);
  };

  const clearBench = () => updateItems(() => []);

  // ── Minimap ────────────────────────────────────────────────────────────────
  const MiniMap = () => {
    const items = activeBench.items;
    if (items.length === 0) return null;
    return (
      <div className="absolute bottom-16 right-2 z-10 w-28 h-20 bg-white/90 border border-[var(--border)] rounded-xl overflow-hidden shadow-md">
        <div className="text-[8px] font-semibold text-[var(--muted)] px-1.5 pt-1">Minimap</div>
        <div className="relative w-full h-14 bg-[var(--chem-muted)]">
          {items.map(ci => (
            <div key={ci.cid}
              className="absolute w-1.5 h-1.5 rounded-sm bg-[var(--chem)] opacity-70"
              style={{ left: `${Math.min(95, (ci.x / 1200) * 100)}%`, top: `${Math.min(90, (ci.y / 800) * 100)}%` }}
            />
          ))}
        </div>
      </div>
    );
  };

  return (
    <div
      className="flex flex-col h-full"
      style={{ fontFamily: "'Outfit', sans-serif" }}
      onClick={() => { setOpenMenu(null); setCtxMenu(null); setSelectedCid(null); }}
    >
      <TopMenuBar
        onBack={onBack} benchName={benchName}
        openMenu={openMenu} setOpenMenu={setOpenMenu}
        onClearBench={clearBench}
      />
      <TabStrip
        benches={benches} active={activeBenchId}
        onSwitch={id => { setActiveBenchId(id); setSelectedCid(null); }}
        onAdd={addBench}
        onClose={closeBench}
      />

      <div className="flex flex-1 overflow-hidden">
        <LeftPanel
          open={leftOpen} onToggle={() => setLeftOpen(o => !o)}
          searchQ={searchQ} setSearchQ={setSearchQ}
          onDragStart={handleSidebarDragStart}
        />

        {/* Canvas area */}
        <div className="flex-1 flex flex-col overflow-hidden relative">
          <FloatingToolbar
            zoom={zoom} onZoom={setZoom}
            isPlaying={isPlaying} onPlayPause={() => setIsPlaying(p => !p)}
            onClearBench={clearBench}
            onUndo={() => {}} onRedo={() => {}}
          />

          {/* REACTION LOG button (like TIMING DIAGRAM) */}
          <button
            className={`absolute top-2 left-2 z-20 flex items-center gap-1.5 bg-white border border-[var(--border)] rounded-lg px-3 py-1.5 text-[11px] font-semibold shadow-sm hover:bg-slate-50 transition-colors ${showReactionLog ? "text-[var(--chem)] border-[var(--chem)]" : "text-[var(--text)]"}`}
            onClick={e => { e.stopPropagation(); setShowReactionLog(o => !o); }}
          >
            REACTION LOG
            <svg className="w-3 h-3 fill-[var(--chem)]" viewBox="0 0 16 16"><path d="M6 3h8v10H6V3zm-4 1h3v2H2V4zm0 3h3v2H2V7zm0 3h3v2H2v-2z"/></svg>
          </button>

          {showReactionLog && (
            <div className="absolute top-11 left-2 z-20 w-64 bg-white border border-[var(--border)] rounded-xl shadow-lg p-3" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">pH over time</span>
                <span className="text-[11px] font-mono font-semibold text-[var(--chem)]">
                  {phLog.length > 0 ? phLog[phLog.length - 1].ph.toFixed(2) : "—"}
                </span>
              </div>
              {phLog.length < 2 ? (
                <div className="text-[10px] text-[var(--muted)] italic py-4 text-center">Add chemicals to the bench to start plotting.</div>
              ) : (
                <svg viewBox="0 0 240 90" className="w-full h-20">
                  <line x1="0" y1="45" x2="240" y2="45" stroke="#E2E8F0" strokeWidth="1" strokeDasharray="3,3" />
                  <polyline
                    fill="none" stroke="#059669" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round"
                    points={phLog.map((p, i) => `${(i / (phLog.length - 1)) * 240},${90 - (p.ph / 14) * 90}`).join(" ")}
                  />
                </svg>
              )}
              <div className="text-[9px] text-[var(--muted)] mt-1">Dashed line marks neutral (pH 7).</div>
            </div>
          )}

          {/* Main canvas */}
          <div
            ref={canvasRef}
            className="canvas-grid flex-1 relative overflow-hidden"
            style={{ cursor: panRef.current.isPanning ? "grabbing" : "default" }}
            onDragOver={handleCanvasDragOver}
            onDrop={handleCanvasDrop}
            onMouseDown={handleCanvasMouseDown}
            onMouseMove={handleCanvasMouseMove}
            onMouseUp={handleCanvasMouseUp}
            onMouseLeave={handleCanvasMouseUp}
            onWheel={handleWheel}
            onContextMenu={e => handleContextMenu(e, "canvas")}
          >
            {/* Pannable/zoomable layer */}
            <div
              style={{
                transform: `translate(${pan.x}px,${pan.y}px) scale(${zoom})`,
                transformOrigin: "0 0",
                position: "absolute",
                top: 0, left: 0,
                width: "1400px", height: "900px",
              }}
            >
              {activeBench.items.map(ci => {
                const labItem = ALL_ITEMS.find(i => i.id === ci.labItemId);
                if (!labItem) return null;
                return (
                  <div
                    key={ci.cid}
                    className="canvas-item"
                    style={{
                      left: ci.x, top: ci.y,
                      zIndex: selectedCid === ci.cid ? 10 : 1,
                      outline: selectedCid === ci.cid ? "2px solid var(--chem)" : "none",
                      outlineOffset: "4px",
                      borderRadius: "12px",
                    }}
                    onPointerDown={e => { e.stopPropagation(); handleItemPointerDown(e, ci.cid); }}
                    onClick={e => { e.stopPropagation(); setSelectedCid(ci.cid); }}
                    onContextMenu={e => handleContextMenu(e, "item", ci.cid)}
                  >
                    <CanvasApparatus
                      ci={ci} labItem={labItem}
                      isDripping={!!titration?.active && titration.buretteCid === ci.cid}
                      isPourTarget={pourHoverCid === ci.cid}
                    />
                  </div>
                );
              })}
            </div>

            {/* Empty bench hint */}
            {activeBench.items.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="text-center text-[var(--muted)] opacity-50">
                  <div className="text-5xl mb-3">⚗️</div>
                  <div className="text-sm font-medium">Drag chemicals and apparatus onto the bench</div>
                  <div className="text-xs mt-1">Use the LAB ELEMENTS panel on the left</div>
                </div>
              </div>
            )}

            <MiniMap />
          </div>

          {/* LAB NOTEBOOK button (like TESTBENCH) */}
          <button
            className={`absolute bottom-14 left-2 z-20 flex items-center gap-1.5 bg-white border border-[var(--border)] rounded-lg px-3 py-1.5 text-[11px] font-semibold shadow-sm hover:bg-slate-50 transition-colors ${showNotebook ? "text-[var(--chem)] border-[var(--chem)]" : "text-[var(--text)]"}`}
            onClick={e => { e.stopPropagation(); setShowNotebook(o => !o); }}
          >
            LAB NOTEBOOK
            <svg className="w-3 h-3 fill-[var(--chem)]" viewBox="0 0 16 16"><path d="M6 3h8v10H6V3zm-4 1h3v2H2V4zm0 3h3v2H2V7zm0 3h3v2H2v-2z"/></svg>
          </button>

          {showNotebook && (
            <div className="absolute bottom-24 left-2 z-20 w-80 bg-white border border-[var(--border)] rounded-xl shadow-lg p-3 max-h-64 flex flex-col" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-2 flex-none">
                <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">Trial Readings</span>
                <button onClick={saveReading} className="text-[10px] font-semibold bg-[var(--chem)] text-white px-2.5 py-1 rounded-lg hover:bg-[var(--chem-hover)] transition-colors">Save Reading</button>
              </div>
              <div className="flex-1 overflow-y-auto">
                {notebook.length === 0 ? (
                  <div className="text-[10px] text-[var(--muted)] italic py-3 text-center">No readings saved yet.</div>
                ) : (
                  <table className="w-full text-[9.5px]">
                    <thead>
                      <tr className="text-left text-[var(--muted)] uppercase tracking-wide">
                        <th className="pb-1 pr-2">Trial</th><th className="pb-1 pr-2">Vol (ml)</th><th className="pb-1 pr-2">Observation</th><th className="pb-1">Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      {notebook.map(row => (
                        <tr key={row.trial} className="border-t border-[var(--border)]">
                          <td className="py-1 pr-2 font-mono">{row.trial}</td>
                          <td className="py-1 pr-2 font-mono">{row.volume}</td>
                          <td className="py-1 pr-2 truncate max-w-[110px]" title={row.observation}>{row.observation}</td>
                          <td className="py-1 text-[var(--chem)] font-medium">{row.result}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}

          {/* Observations bar */}
          <div className="flex-none bg-white border-t border-[var(--border)] h-12 flex items-center gap-3 px-3 overflow-x-auto">
            <div className="text-[9px] font-bold text-[var(--muted)] uppercase tracking-widest flex-shrink-0">Live Readings</div>
            <div className="w-px h-4 bg-[var(--border)]" />
            {observations.length === 0
              ? <span className="text-[10px] text-[var(--muted)] italic">No readings yet — place chemicals on the bench</span>
              : observations.map((obs, i) => (
                <div key={i} className="flex items-center gap-2 bg-[var(--bg)] border border-[var(--border)] rounded-xl px-3 py-1.5 flex-shrink-0">
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full live-dot" style={{ background: obs.color || "var(--chem)" }} />
                    <span className="text-[9px] font-medium text-[var(--muted)] uppercase tracking-wide">{obs.label}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {obs.swatch && <span className="w-3.5 h-3.5 rounded-sm border border-slate-200 inline-block" style={{ background: obs.swatch }} />}
                    <span className="font-mono font-semibold text-[var(--text)] text-[11px]">{obs.value}</span>
                    {obs.unit && <span className="text-[9px] text-[var(--muted)]">{obs.unit}</span>}
                  </div>
                </div>
              ))
            }
          </div>
        </div>

        <RightPanel
          open={rightOpen} onToggle={() => setRightOpen(o => !o)}
          expName={expName} setExpName={setExpName}
          benchName={benchName} setBenchName={setBenchName}
          reactionSpeed={reactionSpeed} setReactionSpeed={setReactionSpeed}
          liveSimulation={liveSimulation} setLiveSimulation={setLiveSimulation}
          liteMode={liteMode} setLiteMode={setLiteMode}
          onSave={() => {}} onClearBench={clearBench}
          chat={chat} chatInput={chatInput} setChatInput={setChatInput} onSendChat={sendChat}
          selectedBurette={selectedCid ? (activeBench.items.find(i => i.cid === selectedCid && i.labItemId === "burette") ?? null) : null}
          otherApparatus={activeBench.items.filter(i => i.cid !== selectedCid).map(i => ({ cid: i.cid, name: ALL_ITEMS.find(li => li.id === i.labItemId)?.name ?? i.labItemId }))}
          titration={titration}
          onStartTitration={startTitration}
          onStopTitration={stopTitration}
        />
      </div>

      {/* Add-chemical popover: form / amount / dissolve-water, then confirm */}
      {pendingDrop && (
        <AddChemicalPopover
          drop={pendingDrop}
          onConfirm={confirmPendingDrop}
          onCancel={() => setPendingDrop(null)}
        />
      )}

      {/* Context menu */}
      {ctxMenu && (
        <ContextMenu
          ctx={ctxMenu}
          onClose={() => setCtxMenu(null)}
          onDelete={cid => { updateItems(prev => prev.filter(i => i.cid !== cid)); }}
          onClear={clearBench}
        />
      )}

      {/* Bottom-right help button */}
      <button className="fixed bottom-4 right-4 w-10 h-10 rounded-full bg-[var(--phys)] text-white flex items-center justify-center shadow-lg hover:bg-[var(--phys)] hover:brightness-110 transition-all z-50">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
      </button>
    </div>
  );
}
