Revise the existing "Open Experiment Space" Figma Make project. Keep the current design tokens exactly as they are — don't introduce a new palette or typeface: --chem #059669 (emerald, chemistry accent), --chem-hover #047857, --chem-light #D1FAE5, --chem-muted #ECFDF5, --phys #7C3AED (violet, reserved for the future physics module), --bg #F8FAFC, --surface #FFFFFF, --border #E2E8F0, --text #1E293B, --muted #64748B, Outfit for UI text, JetBrains Mono for numeric readouts.

REMOVE
- The "Guided" / "Open Mode" toggle and pill in the Workspace header, and the separate Guided Experiments list — there is only one open mode from now on.
- All hardcoded demo values in the workspace (fixed liquidColor props on the beaker/flask SVGs, the fixed pH "7.02", fixed temperature "22.4", fixed "Endpoint Reached ✓" badge, fixed chat script). Everything shown in the workspace must be computed from what the user has actually placed and combined, with an empty/idle state when nothing has been added yet.

EXPAND THE APPARATUS LIBRARY (currently only Burette, Conical Flask, Beaker, Pipette, Retort Stand, Measuring Cylinder, Dropper, Bunsen Burner)
Add these — required by the actual CBSE Class 11/12 practical procedures this app is modeling, not just decorative:
- Pipette bulb (paired with the existing pipette; draws liquid up, never by mouth)
- White tile (sits under the conical flask so a color-change endpoint like phenolphthalein's pink is easier to see — should visually brighten/contrast whatever's placed on it)
- Volumetric flask (for preparing an exact-strength standard solution, e.g. Mohr's salt or oxalic acid in the Class 12 redox titrations)
- Test tube stand/rack (holds multiple test tubes upright side by side — needed once salt analysis involves testing several ions from the same sample)
- Test tube holder (for holding a single tube directly in a flame, distinct from the wire loop used for flame tests)
- Delivery tube (channels evolved gas from one vessel into a test tube of lime water — this should drive an actual "gas bubbled into lime water turns milky" confirmatory reaction, replacing a generic bubble animation with the real CBSE carbonate confirmatory test)
- Watch glass (small-quantity observation/evaporation, and doubles as the flame-test wire-cleaning dish with a drop of concentrated HCl)
- Glass rod, spatula, funnel, wash bottle, filter paper, litmus paper (red & blue), lead acetate paper — small consumable-style items supporting stirring, transferring, and confirmatory strip tests
- China dish (evaporation/ignition tests)
- Nichrome/platinum wire loop, if not already covered by the existing flame-test apparatus

Group these sensibly within the sidebar's "Apparatus" category (e.g. a visual distinction between glassware, stands/holders, and small consumables/test-strips) rather than one long flat list.

EXPAND THE COMPOUND LIBRARY (currently only HCl, NaOH, H₂SO₄, Na₂CO₃, Phenolphthalein, Water, CuSO₄, Litmus — 8 items)
Add these, grouped as shown, so the sidebar reflects the full Class 11/12 syllabus rather than a small demo set:

Titration analytes & standards
- Oxalic acid (COOH)₂ — standard for both the NaOH titration (Class 11) and as a redox standard against KMnO₄ (Class 12)
- Mohr's salt, FeSO₄·(NH₄)₂SO₄·6H₂O — Class 12 redox standard
- Potassium permanganate, KMnO₄ — deep purple; self-indicating, its own color fading is the endpoint
- Methyl orange — second indicator alongside phenolphthalein (yellow → orange/red, used when titrating against carbonate rather than a strong base)

Cation samples (Class 11/12 group scheme — as their common salts)
- Lead nitrate, Pb(NO₃)₂ (Pb²⁺)
- Copper sulfate, CuSO₄ (Cu²⁺) — already present
- Ferric chloride, FeCl₃ (Fe³⁺)
- Aluminium sulfate/alum (Al³⁺)
- Zinc sulfate, ZnSO₄ (Zn²⁺)
- Manganese sulfate, MnSO₄ (Mn²⁺)
- Cobalt nitrate, Co(NO₃)₂ (Co²⁺)
- Nickel sulfate, NiSO₄ (Ni²⁺)
- Calcium chloride, CaCl₂ (Ca²⁺)
- Barium chloride, BaCl₂ (Ba²⁺) — also doubles as a confirmatory reagent, see below
- Strontium chloride, SrCl₂ (Sr²⁺)
- Magnesium sulfate, MgSO₄ (Mg²⁺)
- Ammonium chloride, NH₄Cl (NH₄⁺)

Anion samples (as their sodium/potassium salts)
- Sodium sulphite, Na₂SO₃ (SO₃²⁻)
- Sodium/ammonium sulphide, Na₂S or (NH₄)₂S (S²⁻)
- Sodium nitrite, NaNO₂ (NO₂⁻)
- Sodium chloride, NaCl (Cl⁻) — already present
- Potassium iodide, KI (I⁻)
- Sodium phosphate, Na₃PO₄ (PO₄³⁻)
- Sodium oxalate, Na₂C₂O₄ (C₂O₄²⁻)
- Sodium acetate, CH₃COONa (CH₃COO⁻)
- Potassium/sodium nitrate, KNO₃ or NaNO₃ (NO₃⁻)
- Sodium carbonate, Na₂CO₃ (CO₃²⁻) — already present

Group reagents & confirmatory test reagents (needed to actually run the salt-analysis procedure, not just present a salt)
- Dilute sulfuric acid, dilute H₂SO₄ (Group I anion test) — already present
- Concentrated sulfuric acid, conc. H₂SO₄ (Group II anion test)
- Dilute hydrochloric acid, dilute HCl — already present
- Ammonium hydroxide, NH₄OH (cation group reagent)
- Ammonium carbonate, (NH₄)₂CO₃ (cation group reagent)
- Silver nitrate, AgNO₃ (halide confirmatory test)
- Lead acetate solution, Pb(CH₃COO)₂ (sulphide gas confirmatory test — turns black)
- Potassium ferrocyanide, K₄[Fe(CN)₆] (Fe³⁺/Fe²⁺ confirmatory test)
- Potassium dichromate, K₂Cr₂O₇ (sulphite/oxidation confirmatory tests)
- Starch solution (iodide/iodine confirmatory test)
- Lime water, Ca(OH)₂ solution (CO₂ gas confirmatory test — turns milky)
- Nessler's reagent (NH₄⁺ confirmatory test)

Keep the existing Phenolphthalein and Litmus Solution as-is under Indicators, and add Methyl Orange there too. Group all of the above into sidebar sub-categories — Acids, Bases, Titration Standards, Cation Salts, Anion Salts, Group/Test Reagents, Indicators — rather than one flat "Compounds" list, since a flat list of 30+ items would be unusable without grouping.

CORE WORKSPACE CHANGES
1. Single unified workspace: no mode switching. The same apparatus and compounds support titration, salt analysis, and flame test in one space; the user decides what to do.
2. Compound selection with real form/amount control: selecting a compound from the sidebar offers Solid or Liquid. Solid → placed in a test tube, then the user sets how much water to dissolve it in via a slider (this sets concentration, not a fixed "Dilute · 0.1 M" label — remove those static strength labels from the compound cards entirely). Liquid → user sets ml directly. Show this control inline at the point of adding, not as a separate settings screen.
3. Larger compound preview on selection: before dragging a compound onto the canvas, show an enlarged preview of its real color and texture (crystal, powder, clear liquid, colored solution) — bigger than the current small sidebar card.
4. Live, computed apparatus rendering: the beaker/flask/test-tube fill color and level must be derived from actual contents and concentration, not passed in as a static prop. Add an auto-updating text label under each apparatus stating contents in plain language, e.g. "Test Tube 1: Na₂CO₃ (solid) + 15ml water."
5. Burette drip-rate control: a dial or slider on the burette setting drops-per-second, with a live volume-added readout, replacing the current fixed-level BuretteSVG.
6. Open combination: pouring one filled apparatus into another computes the result (color change, gas bubbles, precipitate) from the actual pair combined — remove the single scripted HCl/NaOH/phenolphthalein narrative currently hardcoded into the AI chat log; the AI panel should react to whatever the user does.
7. Pannable/zoomable canvas: the canvas must support panning in all directions and zooming in/out, with zoom controls and a reset-view button — it's currently a fixed viewport.
8. FIX THE CANVAS BACKGROUND PATTERN: the current `.canvas-grid` background is a dotted pattern (radial-gradient of small dots). Replace it with a square line-grid, like graph paper — thin straight lines forming even squares, matching CircuitVerse's workbench background exactly, not dots. Keep the same soft green-tinted background color, just change dots to grid lines.

MATCH CIRCUITVERSE'S ACTUAL WORKSPACE STRUCTURE (reference screenshots attached), reskinned into the tokens above — do not adopt CircuitVerse's dark chrome:
- Top menu bar: alongside the existing logo/nav, add CircuitVerse-style dropdown menus: "Experiment" (New Experiment, Save Online, Save Offline, Open Offline, Export as File, Import File, Clear Bench, Recover Experiment, Preview Bench), "Tools" (Concentration/Molarity Converter, Download Image, Themes, Custom Shortcuts), "Help" (Tutorial Guide, User Manual, Learn Chemistry Basics, Discussion Forum). Keep it as understated as CircuitVerse's — text-only dropdowns, no icons needed here.
- Tab strip under the top bar: an open experiment is a closable tab ("Bench 1 ×") with a "+" to start a new, independent workspace — same mechanic as CircuitVerse's circuit tabs, so a student can run more than one experiment in parallel.
- Left panel restructured like CircuitVerse's "CIRCUIT ELEMENTS" panel exactly: header bar with collapse toggle, search bar directly under it, collapsible categories with a chevron each expanding into a dense small-icon grid (icon + tiny label, 2–3 per row) rather than the current full-width SidebarCard list. Categories per the expanded lists above: Apparatus (subgrouped), Acids, Bases, Titration Standards, Cation Salts, Anion Salts, Group/Test Reagents, Indicators.
- Floating labelled buttons on the canvas matching CircuitVerse's "TIMING DIAGRAM" (top-left) and "TESTBENCH" (bottom-left) in position and style:
   • "Reaction Log" — opens a panel plotting pH and temperature live over the course of the experiment (line graph), replacing the currently-static ReadoutBadge values with a real time series.
   • "Lab Notebook" — modeled directly on CircuitVerse's Testbench table (Test/Type/Group/Case columns, Validate, Run All, Tests Passed counter): a table where each row is a titration trial with columns Trial No., Volume Used (ml), Observation, Result, plus "Save Reading" and "View All Readings" — mirrors the actual burette-reading table CBSE practicals require students to keep.
- Thin floating toolbar centered above canvas, same icon order as CircuitVerse's: drag handle, save, clear bench, export-as-image (PNG/JPEG/SVG, current view or full bench, transparent background toggle — matching CircuitVerse's Download Image dialog exactly), pan-tool toggle, undo, redo, fullscreen, then the zoom slider with − / + from point 7.
- Right panel restructured like CircuitVerse's "PROPERTIES" panel: header with collapse toggle, "Experiment Properties" section with Experiment Name and Bench Name fields, a "Reaction Speed (ms)" stepper (replacing Clock Time) controlling how fast color changes/bubbling/dripping animate, a "Live Simulation" toggle (replacing Clock Enabled) for real-time vs step-by-step rendering, and keep "Lite Mode" worded exactly as CircuitVerse does — it directly serves our stated audience on older/shared school computers by reducing rendered visual detail. Keep the green primary action button ("Save Layout") and a red destructive button ("Clear Bench").
- Right-click quick menu on the canvas, matching CircuitVerse's: Save Online, Save Offline, Download Image, Copy Selected, Paste Selected, Selection Tool, Report Issue. Right-click on a placed apparatus: Copy, Cut, Delete, Undo, Center Focus.
- A simple Light/Dark theme picker under Tools → Themes, defaulting to Light, since Dark should stay optional rather than default given the audience.
- Keep the small circular help/feedback button fixed bottom-right, as in the reference screenshots.

ADDITIONAL CIRCUITVERSE PARITY FEATURES (found via CircuitVerse's docs/source, not just the visible UI)
- Add a Play/Pause control for the live simulation (bubbling, dripping, color-transition animations) in the floating toolbar, bound to the spacebar as a keyboard shortcut — matching CircuitVerse's engine play/pause behavior exactly.
- Add a small minimap fixed in a corner of the canvas once panning/zooming is implemented, so users can see where their placed apparatus sit relative to the full pannable area.
- Selected apparatus can be nudged in small increments using the arrow keys, for precise repositioning without a mouse.
- Support copy/paste of a placed apparatus (with its current contents) between open bench tabs, matching CircuitVerse's cross-project circuit copy-paste.

CHEMISTRY CONTENT SCOPE (ground reactions and demos in what's actually taught)
- Class 11 titrations: HCl vs. standard sodium carbonate; NaOH vs. standard oxalic acid.
- Class 12 titrations (redox): standardising Mohr's salt or oxalic acid against potassium permanganate — KMnO₄'s own pink-purple color as the endpoint, no separate indicator needed.
- Salt analysis anion groups: Group I (dilute H₂SO₄) — carbonate (colourless, odourless CO₂), sulphite (colourless, pungent gas), sulphide (rotten-egg gas, blackens lead acetate paper), nitrite; Group II (conc. H₂SO₄) — halides and others. Cation testing follows the standard group scheme (Pb²⁺, Cu²⁺, Fe³⁺, Zn²⁺, Ca²⁺, Ba²⁺, NH₄⁺, etc.), using the ammonium hydroxide/ammonium carbonate group reagents and confirmatory reagents listed above.
- Flame test colors tie directly into cation confirmation (e.g. Cu²⁺ green), so the flame-test loop and the salt-analysis cation tests should reference the same compound dataset rather than two separate lists.

Keep the AI Assistant panel, module switcher (Chemistry / Physics), and the overall Observations strip concept — but make every value in them computed, not hardcoded, per the REMOVE section above.